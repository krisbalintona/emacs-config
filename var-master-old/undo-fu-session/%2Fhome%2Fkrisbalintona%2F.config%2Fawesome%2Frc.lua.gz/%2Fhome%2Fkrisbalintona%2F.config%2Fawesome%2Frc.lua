((buffer-size . 22351) (buffer-checksum . "4a0260146f737a9021cf37b2a9f51ad16f2299fa"))
((emacs-buffer-undo-list nil (apply -9 2479 2582 undo--wrap-and-run-primitive-undo 2479 2582 ((2551 . 2554) (2515 . 2518) (2481 . 2484) 2506)) nil (apply -6 2761 2829 undo--wrap-and-run-primitive-undo 2761 2829 ((2797 . 2800) (2763 . 2766) 2785)) (t 24506 17559 989604 994000) nil ("require(\"collision\")()
" . 294) (t 24506 17315 86651 391000) nil (314 . 316) ("(" . -314) (314 . 315) (t 24506 17306 153088 614000) nil (")" . 314) (313 . 314) (" " . -313) (313 . 314) (")" . -313) (313 . 314) (t 24506 17306 153088 614000) ("\"" . 313) (312 . 313) (" " . -312) (312 . 313) ("\"" . -312) (312 . 313) (t 24506 17306 153088 614000) (307 . 312) nil ("u" . -307) ("s" . -308) ("i" . -309) ("o" . -310) ("n" . -311) 312 (t 24506 17303 213013 103000) nil (307 . 312) nil ("u" . -307) 308 nil (307 . 308) nil (303 . 307) nil ("awful.autofocus" . 303) 317 nil ("
" . 294) nil (nil rear-nonsticky nil 294 . 295) ("
" . -321) (294 . 322) nil (293 . 294) (t 24506 17137 532089 453000) 267 nil (12270 . 12271) ("c" . 12270) nil (", \"Shift\"  " . 12265) 12275 (t 24506 16983 558129 522000) nil (11374 . 11379) ("P" . -11374) ("r" . -11375) 11376 (11374 . 11376) ("Prompt" . 11374) 11380 (t 24506 16975 81244 716000) nil (11420 . 11422) (11417 . 11420) ("r" . 11417) (t 24506 16949 350582 485000) nil (11500 . 11504) ("e" . -11500) 11501 (11492 . 11501) ("run prompt" . 11492) 11501 (t 24506 16925 879978 295000) nil (11456 . 11464) ("e" . -11456) ("m" . -11457) 11458 (11457 . 11458) (11455 . 11457) (t 24506 16921 466531 335000) (11454 . 11456) ("\"" . -11454) (11454 . 11455) (11453 . 11455) ("(" . -11453) (11453 . 11454) (t 24506 16918 763128 398000) (11437 . 11453) (t 24506 16913 39647 700000) ("awful.screen.focused().mypromptbox:run()" . 11437) 11476 (t 24506 16517 566107 365000) nil (18827 . 18832) ("true" . 18827) (t 24506 16486 238629 406000) nil ("      s.mytasklist, -- Middle widget
      { -- Right widgets
        layout = wibox.layout.fixed.horizontal,
        mykeyboardlayout,
        wibox.widget.systray(),
        mytextclock,
        s.mylayoutbox,
      },
" . 7038) 7256 (t 24506 16383 499298 157000) nil (1953 . 1956) ("n" . -1953) ("v" . -1954) ("i" . -1955) 1956 (1952 . 1956) ("EDITOR" . 1952) (t 24506 16369 188926 487000) nil (1925 . 1930) ("xterm" . 1925) (t 24506 16317 364245 953000) nil (apply -3 2422 2455 undo--wrap-and-run-primitive-undo 2422 2455 ((2424 . 2427) 2425)) (t 24506 16111 878882 54000) nil ("&" . 22518) nil (" " . 22518) 22519 nil (" " . 22572) 22573 nil ("&" . 22573) nil ("awful.spawn.with_shell(\"\")
" . 22577) 22603 nil (nil rear-nonsticky nil 22573 . 22574) (nil fontified nil 22547 . 22574) (22547 . 22574) (t 24506 16096 738485 160000) nil (nil rear-nonsticky nil 22519 . 22520) (nil fontified nil 22513 . 22520) (22513 . 22520) (t 24506 16013 312959 885000) nil (nil rear-nonsticky nil 22485 . 22486) (nil fontified nil 22459 . 22486) (22459 . 22486) (t 24506 15979 838744 442000) nil ("awful.spawn.with_shell(\"\")
" . 22543) nil (nil rear-nonsticky nil 22542 . 22543) ("
" . -22569) (22542 . 22570) 22516 nil (nil rear-nonsticky nil 22515 . 22516) ("
" . -22542) (22515 . 22543) 22489 nil (nil rear-nonsticky nil 22488 . 22489) ("
" . -22515) (22488 . 22516) 22462 nil (nil rear-nonsticky nil 22461 . 22462) ("
" . -22488) (22461 . 22489) 22459 nil ("betterlockscreen -w" . 22459) 22477 nil (nil rear-nonsticky nil 22434 . 22435) ("
" . -22480) (22434 . 22481) 22432 (t 24506 15965 175024 182000) nil (nil rear-nonsticky nil 22431 . 22432) (nil fontified nil 22413 . 22432) (22413 . 22432) (t 24506 15846 11866 984000) nil (22412 . 22414) ("\"" . -22412) (22412 . 22413) ("'" . -22412) 22413 (22412 . 22413) (22411 . 22413) ("(" . -22411) (22411 . 22412) (t 24506 15835 924931 910000) nil ("(" . -22411) 22412 (22411 . 22412) ("(" . -22411) ("\"" . -22412) 22413 (")" . 22413) ("\"" . 22413) (t 24506 15731 835483 216000) nil (22413 . 22415) ("'" . -22413) 22414 (22412 . 22414) ("'" . -22412) 22413 (22411 . 22413) (t 24506 15723 265253 79000) (22401 . 22411) (t 24506 15719 981831 529000) (22400 . 22401) (22394 . 22400) (t 24506 15715 258371 242000) (22389 . 22395) (t 24506 15680 227427 967000) ("
" . -22389) (22388 . 22389) (t 24506 15674 560608 414000) (22381 . 22388) ("s" . -22381) 22382 (22379 . 22382) ("A" . -22379) 22380 (22376 . 22380) (22375 . 22376) (22374 . 22375) (t 24506 15659 526869 63000) 22370 nil ("s" . 22370) (t 24506 15654 783407 496000) nil (22371 . 22375) (22367 . 22371) (t 24506 15573 971212 780000) nil (22344 . 22348) ("G" . -22344) ("a" . -22345) ("p" . -22346) ("s" . -22347) 22348 nil ("p" . -22367) 22368 (22367 . 22368) ("a" . -22367) ("p" . -22368) 22369 (22367 . 22369) (22366 . 22367) ("." . -22366) 22367 (22366 . 22367) (t 24506 15550 37225 531000) ("-" . -22366) 22367 (22362 . 22367) ("f" . -22362) ("l" . -22363) 22364 (22358 . 22364) (" " . -22358) 22359 (t 24506 15545 467100 448000) (22355 . 22359) (22349 . 22355) (22348 . 22349) (t 24506 15539 116926 530000) (22341 . 22349) (22340 . 22341) (t 24506 13554 118091 542000) 22340 nil ("
" . 702) (t 24506 13490 166670 800000) nil (702 . 703) (t 24505 27986 363964 564000) 702 nil (22339 . 22340) 3747 nil (22057 . 22081) ("    " . -22057) (21896 . 21946) ("    " . -21896) (21831 . 21857) ("        " . -21831) (21802 . 21828) ("        " . -21802) (21733 . 21761) ("            " . -21733) (21663 . 21691) ("            " . -21663) (21593 . 21621) ("            " . -21593) (21523 . 21551) ("            " . -21523) (21453 . 21481) ("            " . -21453) (21383 . 21411) ("            " . -21383) (21346 . 21372) ("        " . -21346) (21317 . 21343) ("        " . -21317) (21250 . 21278) ("            " . -21250) (21203 . 21231) ("            " . -21203) (21172 . 21200) ("            " . -21172) (21096 . 21126) ("                " . -21096) (21047 . 21077) ("                " . -21047) (21008 . 21036) ("            " . -21008) (20970 . 20996) ("        " . -20970) (20941 . 20967) ("        " . -20941) (20873 . 20901) ("            " . -20873) (20826 . 20854) ("            " . -20826) (20761 . 20789) ("            " . -20761) (20725 . 20751) ("        " . -20725) (20673 . 20697) ("    " . -20673) (20646 . 20670) ("    " . -20646) (20615 . 20641) ("        " . -20615) (20556 . 20586) ("            " . -20556) (20463 . 20493) ("            " . -20463) (20405 . 20431) ("        " . -20405) (20373 . 20399) ("        " . -20373) (20316 . 20346) ("            " . -20316) (20223 . 20253) ("            " . -20223) (20165 . 20191) ("        " . -20165) (20107 . 20131) ("    " . -20107) (20055 . 20079) ("    " . -20055) (19897 . 19921) ("    " . -19897) (19839 . 19865) ("        " . -19839) (19743 . 19769) ("        " . -19743) (19674 . 19700) ("      " . -19674) (19613 . 19639) ("      " . -19613) (19570 . 19594) ("    " . -19570) (19485 . 19509) ("    " . -19485) (19395 . 19419) ("    " . -19395) (19338 . 19362) ("    " . -19338) (19162 . 19164) ("    " . -19162) (19125 . 19127) ("    " . -19125) (19060 . 19062) ("    " . -19060) (19054 . 19056) ("    " . -19054) (18994 . 19009) ("      " . -18994) (18948 . 18950) ("    " . -18948) (18899 . 18901) ("    " . -18899) (18858 . 18860) ("      " . -18858) (18850 . 18856) ("        " . -18850) (18774 . 18782) ("          " . -18774) (18717 . 18725) ("          " . -18717) (18666 . 18674) ("          " . -18666) (18651 . 18657) ("        " . -18651) (18642 . 18648) ("        " . -18642) (18609 . 18617) ("          " . -18609) (18594 . 18600) ("        " . -18594) (18524 . 18530) ("        " . -18524) (18421 . 18427) ("        " . -18421) (18392 . 18400) ("          " . -18392) (18373 . 18381) ("          " . -18373) (18354 . 18362) ("          " . -18354) (18262 . 18270) ("          " . -18262) (18246 . 18254) ("          " . -18246) (18212 . 18220) ("          " . -18212) (18194 . 18202) ("          " . -18194) (18177 . 18185) ("          " . -18177) (18150 . 18158) ("          " . -18150) (18132 . 18140) ("          " . -18132) (18116 . 18122) ("        " . -18116) (18107 . 18113) ("        " . -18107) (18087 . 18095) ("          " . -18087) (18034 . 18042) ("          " . -18034) (17988 . 17996) ("          " . -17988) (17969 . 17975) ("        " . -17969) (17952 . 17954) ("    " . -17952) (17929 . 17931) ("    " . -17929) (17923 . 17925) ("    " . -17923) (17917 . 17921) ("     " . -17917) (17830 . 17849) ("                     " . -17830) (17778 . 17797) ("                     " . -17778) (17734 . 17753) ("                     " . -17734) (17696 . 17715) ("                     " . -17696) (17663 . 17682) ("                     " . -17663) (17609 . 17628) ("                     " . -17609) (17550 . 17569) ("                     " . -17550) (17492 . 17496) ("      " . -17492) (17476 . 17478) ("    " . -17476) (17437 . 17439) ("    " . -17437) (17286 . 17288) ("    " . -17286) (17251 . 17257) ("        " . -17251) (17179 . 17185) ("        " . -17179) (17136 . 17138) ("    " . -17136) (17128 . 17130) ("    " . -17128) (17095 . 17101) ("        " . -17095) (17023 . 17029) ("        " . -17023) (16980 . 16982) ("    " . -16980) (16972 . 16974) ("    " . -16972) (16900 . 16906) ("        " . -16900) (16864 . 16866) ("    " . -16864) (16821 . 16823) ("    " . -16821) (16717 . 16751) ("                  " . -16717) (16678 . 16712) ("                  " . -16678) (16638 . 16674) ("                      " . -16638) (16596 . 16634) ("                          " . -16596) (16527 . 16567) ("                              " . -16527) (16477 . 16515) ("                          " . -16477) (16399 . 16437) ("                          " . -16399) (16342 . 16378) ("                      " . -16342) (16296 . 16330) ("                  " . -16296) (16208 . 16240) ("        " . -16208) (16143 . 16175) ("        " . -16143) (16042 . 16076) ("                  " . -16042) (16003 . 16037) ("                  " . -16003) (15963 . 15999) ("                     " . -15963) (15921 . 15959) ("                          " . -15921) (15851 . 15891) ("                              " . -15851) (15801 . 15839) ("                          " . -15801) (15723 . 15761) ("                          " . -15723) (15666 . 15702) ("                      " . -15666) (15620 . 15654) ("                  " . -15620) (15543 . 15575) ("        " . -15543) (15488 . 15520) ("        " . -15488) (15401 . 15435) ("                  " . -15401) (15362 . 15396) ("                  " . -15362) (15322 . 15358) ("                      " . -15322) (15258 . 15296) ("                         " . -15258) (15210 . 15246) ("                      " . -15210) (15147 . 15183) ("                      " . -15147) (15073 . 15109) ("                      " . -15073) (15027 . 15061) ("                  " . -15027) (14948 . 14980) ("        " . -14948) (14893 . 14925) ("        " . -14893) (14810 . 14844) ("                  " . -14810) (14771 . 14805) ("                  " . -14771) (14731 . 14767) ("                        " . -14731) (14677 . 14715) ("                           " . -14677) (14629 . 14665) ("                        " . -14629) (14566 . 14602) ("                        " . -14566) (14492 . 14528) ("                        " . -14492) (14446 . 14480) ("                  " . -14446) (14378 . 14410) ("        " . -14378) (14328 . 14360) ("        " . -14328) (14284 . 14286) ("    " . -14284) (14026 . 14030) ("        " . -14026) (14016 . 14020) ("        " . -14016) (14000 . 14006) ("            " . -14000) (13942 . 13948) ("            " . -13942) (13925 . 13929) ("        " . -13925) (13885 . 13887) ("    " . -13885) (13819 . 13823) ("        " . -13819) (13809 . 13813) ("        " . -13809) (13793 . 13799) ("            " . -13793) (13739 . 13745) ("            " . -13739) (13722 . 13726) ("        " . -13722) (13682 . 13684) ("    " . -13682) (13627 . 13631) ("        " . -13627) (13617 . 13621) ("        " . -13617) (13601 . 13607) ("            " . -13601) (13565 . 13571) ("            " . -13565) (13548 . 13552) ("        " . -13548) (13508 . 13510) ("    " . -13508) (13457 . 13461) ("        " . -13457) (13447 . 13451) ("        " . -13447) (13422 . 13428) ("            " . -13422) (13356 . 13362) ("            " . -13356) (13289 . 13295) ("            " . -13289) (13272 . 13276) ("        " . -13272) (13232 . 13234) ("    " . -13232) (13171 . 13175) ("              " . -13171) (13075 . 13077) ("    " . -13075) (13018 . 13022) ("              " . -13018) (12922 . 12924) ("    " . -12922) (12865 . 12869) ("              " . -12865) (12769 . 12771) ("    " . -12769) (12711 . 12715) ("              " . -12711) (12615 . 12617) ("    " . -12615) (12567 . 12571) ("              " . -12567) (12471 . 12473) ("    " . -12471) (12411 . 12415) ("        " . -12411) (12402 . 12406) ("        " . -12402) (12386 . 12392) ("            " . -12386) (12348 . 12354) ("            " . -12348) (12331 . 12335) ("        " . -12331) (12291 . 12293) ("    " . -12291) (12197 . 12201) ("              " . -12197) (12137 . 12139) ("    " . -12137) (12124 . 12126) ("    " . -12124) (12062 . 12066) ("              " . -12062) (12053 . 12057) ("              " . -12053) (12045 . 12051) ("                  " . -12045) (11976 . 11984) ("                    " . -11976) (11936 . 11944) ("                    " . -11936) (11870 . 11878) ("                    " . -11870) (11829 . 11837) ("                    " . -11829) (11804 . 11810) ("                  " . -11804) (11788 . 11792) ("              " . -11788) (11759 . 11761) ("    " . -11759) (11703 . 11707) ("              " . -11703) (11601 . 11603) ("    " . -11601) (11589 . 11591) ("    " . -11589) (11528 . 11532) ("              " . -11528) (11519 . 11523) ("              " . -11519) (11509 . 11515) ("                  " . -11509) (11499 . 11507) ("                    " . -11499) (11435 . 11445) ("                        " . -11435) (11412 . 11420) ("                    " . -11412) (11396 . 11402) ("                  " . -11396) (11365 . 11371) ("                  " . -11365) (11326 . 11332) ("                  " . -11326) (11310 . 11314) ("              " . -11310) (11270 . 11272) ("    " . -11270) (11211 . 11215) ("              " . -11211) (11114 . 11116) ("    " . -11114) (11060 . 11064) ("              " . -11060) (10963 . 10965) ("    " . -10963) (10890 . 10894) ("              " . -10890) (10793 . 10795) ("    " . -10793) (10720 . 10724) ("              " . -10720) (10623 . 10625) ("    " . -10623) (10543 . 10547) ("              " . -10543) (10446 . 10448) ("    " . -10446) (10366 . 10370) ("              " . -10366) (10269 . 10271) ("    " . -10269) (10198 . 10202) ("              " . -10198) (10101 . 10103) ("    " . -10101) (10030 . 10034) ("              " . -10030) (9933 . 9935) ("    " . -9933) (9876 . 9880) ("              " . -9876) (9822 . 9824) ("    " . -9822) (9764 . 9768) ("              " . -9764) (9707 . 9709) ("    " . -9707) (9647 . 9651) ("              " . -9647) (9563 . 9565) ("    " . -9563) (9541 . 9543) ("    " . -9541) (9490 . 9494) ("        " . -9490) (9481 . 9485) ("        " . -9481) (9471 . 9477) ("            " . -9471) (9442 . 9450) ("                " . -9442) (9415 . 9421) ("            " . -9415) (9371 . 9377) ("            " . -9371) (9355 . 9359) ("        " . -9355) (9313 . 9315) ("    " . -9313) (9249 . 9253) ("              " . -9249) (9181 . 9183) ("    " . -9181) (9113 . 9117) ("              " . -9113) (9024 . 9026) ("    " . -9024) (8960 . 8964) ("              " . -8960) (8871 . 8873) ("    " . -8871) (8794 . 8798) ("              " . -8794) (8705 . 8707) ("    " . -8705) (8632 . 8636) ("              " . -8632) (8543 . 8545) ("    " . -8543) (8518 . 8520) ("    " . -8518) (8459 . 8463) ("              " . -8459) (8384 . 8386) ("    " . -8384) (8379 . 8381) ("    " . -8379) (8315 . 8319) ("        " . -8315) (8306 . 8310) ("        " . -8306) (8271 . 8277) ("            " . -8271) (8255 . 8259) ("        " . -8255) (8215 . 8217) ("    " . -8215) (8210 . 8212) ("    " . -8210) (8150 . 8154) ("        " . -8150) (8141 . 8145) ("        " . -8141) (8106 . 8112) ("            " . -8106) (8090 . 8094) ("        " . -8090) (8050 . 8052) ("    " . -8050) (8002 . 8006) ("              " . -8002) (7930 . 7932) ("    " . -7930) (7881 . 7885) ("              " . -7881) (7816 . 7818) ("    " . -7816) (7763 . 7767) ("              " . -7763) (7698 . 7700) ("    " . -7698) (7649 . 7653) ("              " . -7649) (7579 . 7581) ("    " . -7579) (7461 . 7476) ("    " . -7461) (7404 . 7419) ("    " . -7404) (7330 . 7345) ("    " . -7330) (7249 . 7255) ("        " . -7249) (7226 . 7234) ("            " . -7226) (7205 . 7213) ("            " . -7205) (7173 . 7181) ("            " . -7173) (7147 . 7155) ("            " . -7147) (7099 . 7107) ("            " . -7099) (7074 . 7080) ("        " . -7074) (7037 . 7043) ("        " . -7037) (7028 . 7034) ("        " . -7028) (7005 . 7013) ("            " . -7005) (6984 . 6992) ("            " . -6984) (6964 . 6972) ("            " . -6964) (6916 . 6924) ("            " . -6916) (6892 . 6898) ("        " . -6892) (6846 . 6852) ("        " . -6846) (6665 . 6671) ("        " . -6665) (6607 . 6613) ("        " . -6607) (6588 . 6594) ("        " . -6588) (6474 . 6480) ("        " . -6474) (6425 . 6431) ("        " . -6425) (6406 . 6412) ("        " . -6406) (6245 . 6273) ("                           " . -6245) (6157 . 6185) ("                           " . -6157) (6069 . 6097) ("                           " . -6069) (5981 . 6009) ("                           " . -5981) (5295 . 5297) ("    " . -5295) (5245 . 5249) ("        " . -5245) (5237 . 5241) ("        " . -5237) (5206 . 5212) ("            " . -5206) (5164 . 5168) ("        " . -5164) (5105 . 5109) ("        " . -5105) (5063 . 5067) ("        " . -5063) (5033 . 5035) ("    " . -5033) (5018 . 5020) ("    " . -5018) ("                                          " . -4979) (4944 . 4950) ("                                              " . -4944) (4909 . 4911) ("                     " . -4909) (4901 . 4903) ("                                          " . -4901) (4867 . 4873) ("                                              " . -4867) (4832 . 4834) ("                     " . -4832) (4824 . 4826) ("                                          " . -4824) (4766 . 4772) ("                                              " . -4766) (4732 . 4734) ("                     " . -4732) (4724 . 4726) ("                                          " . -4724) (4714 . 4720) ("                                              " . -4714) (4704 . 4712) ("                                                  " . -4704) (4679 . 4689) ("                                                      " . -4679) (4657 . 4667) ("                                                      " . -4657) (4626 . 4636) ("                                                      " . -4626) (4603 . 4611) ("                                                  " . -4603) (4592 . 4598) ("                                              " . -4592) (4565 . 4573) ("                                                  " . -4565) (4533 . 4539) ("                                              " . -4533) (4497 . 4499) ("                     " . -4497) ("                " . -4451) (4382 . 4384) ("                    " . -4382) (4312 . 4314) ("                    " . -4312) (4304 . 4306) ("                                          " . -4304) (4294 . 4300) ("                                              " . -4294) (4259 . 4267) ("                                                  " . -4259) (4232 . 4238) ("                                              " . -4232) (4190 . 4192) ("                    " . -4190) (4144 . 4146) ("                    " . -4144) (4136 . 4138) ("                                          " . -4136) (4126 . 4132) ("                                              " . -4126) (4090 . 4098) ("                                                  " . -4090) (4063 . 4069) ("                                              " . -4063) (4021 . 4023) ("                    " . -4021) (3966 . 3968) ("                    " . -3966) (3433 . 3456) ("                        " . -3433) ("                                  " . -3431) (3373 . 3401) ("                                    " . -3373) (3235 . 3237) ("   " . -3235) (3201 . 3203) ("   " . -3201) (3141 . 3143) ("   " . -3141) (3094 . 3096) ("   " . -3094) (3008 . 3010) ("   " . -3008) (2890 . 2892) ("    " . -2890) (2856 . 2858) ("    " . -2856) (2822 . 2824) ("    " . -2822) (2791 . 2793) ("    " . -2791) (2760 . 2762) ("    " . -2760) (2724 . 2726) ("    " . -2724) (2699 . 2701) ("    " . -2699) (2663 . 2665) ("    " . -2663) (2635 . 2637) ("    " . -2635) (2598 . 2600) ("    " . -2598) (2572 . 2574) ("    " . -2572) (2542 . 2544) ("    " . -2542) (2509 . 2511) ("    " . -2509) (2478 . 2480) ("    " . -2478) (2452 . 2454) ("    " . -2452) (2422 . 2424) ("    " . -2422) (1673 . 1675) ("    " . -1673) (1629 . 1656) ("        " . -1629) (1561 . 1605) ("                         " . -1561) (1481 . 1525) ("                         " . -1481) (1395 . 1422) ("        " . -1395) (1351 . 1378) ("        " . -1351) (1296 . 1323) ("        " . -1296) (1217 . 1244) ("        " . -1217) (1161 . 1163) ("    " . -1161) (1136 . 1138) ("    " . -1136) 22934 nil (1037 . 1056) ("                     " . -1037) (967 . 986) ("                     " . -967) (906 . 908) ("    " . -906) 1121 nil ("if awesome.startup_errors then
" . 1100) nil ("
" . 1131) nil ("  " . -1131) 1133 (1130 . 1133) nil (1100 . 1131) 1104 ("if 
" . 1100) 1104 nil (1100 . 1103) ("l" . -1100) ("u" . -1101) 1102 (1100 . 1102) ("d" . -1100) ("o" . -1101) ("
" . -1102) (" " . -1103) (" " . -1104) ("l" . -1105) ("u" . -1106) 1107 (1105 . 1107) (1102 . 1105) (" " . -1102) 1103 (1100 . 1103) ("t" . -1100) 1101 (1100 . 1101) (1099 . 1100) (t 24505 26778 326776 290000) 1099) (emacs-pending-undo-list ("
" . 1050) (72 . 1554) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config
  

    (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
      (setq eshell-history-buffer-when-process-dies t)
      (setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
     :keymaps 'eshell-mode-map
     :stats '(normal visual motion)
     [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
     )
    )
" . 72) ((marker* . 2974) . 504) ((marker . 2974) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker) . -980) ((marker) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -1484) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker) . -980) ((marker . 72) . -980) ("    (face-remap-add-relative 'default :height 127) ; Change default face size
" . 1052) ((marker) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker . 72) . -78) ((marker) . -78) ((marker . 72) . -78) (nil rear-nonsticky t 1129 . 1130) nil (nil rear-nonsticky nil 1129 . 1130) (1052 . 1130) (72 . 1556) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config


    (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
      (setq eshell-history-buffer-when-process-dies t)
      (setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
     :keymaps 'eshell-mode-map
     :stats '(normal visual motion)
     [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
     )
    )
" . 72) ((marker . 2974) . -978) ((marker . 1082) . -978) ((marker* . 1197) . 503) ((marker . 1122) . -978) ((marker . 1099) . -978) ((marker . 1050) . -978) ((marker . 1215) . -978) ((marker . 1050) . -978) ((marker . 1050) . -978) ((marker . 1050) . -978) ((marker . 1050) . -978) ((marker) . -978) ((marker) . -978) 1050 (1050 . 1051) nil ("    (face-remap-add-relative 'default :height 127) ; Change default face size
" . 1050) ((marker) . -78) ((marker . 1050) . -78) ((marker . 1050) . -78) ((marker . 1050) . -78) ((marker) . -78) nil (1050 . 1128) ("27" . 1050) ((marker . 1215) . -1) ((marker) . -2) (nil rear-nonsticky t 1051 . 1052) nil (nil rear-nonsticky nil 1051 . 1052) (nil fontified nil 1050 . 1052) (1050 . 1052) 1128 ("    (face-remap-add-relative 'default :height 127) ; Change default face size
" . 1050) ((marker . 2974) . -78) ((marker . 1122) . -8) ((marker . 1099) . -8) ((marker) . -8) ((marker) . -8) ((marker) . -8) 1128 nil (10272 . 10274) ("27" . 10272) nil (9585 . 10328) ("    ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
    ;;  '(vterm :build '((\"mkdir -p build\")
    ;;                   (\"cd build\")
    ;;                   (\"cmake ..\")
    ;;                   (\"make\"))
    ;;          ))

    (use-package vterm
      :hook (vterm-mode . (lambda ()
                            (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                            (buffer-face-mode t)))
      :custom
      (vterm-kill-buffer-on-exit nil)
      (vterm-copy-exclude-prompt t)
      (vterm-min-window-width 50)
    :config
  (add-hook 'vterm-mode-hook
          (lambda ()
                  (face-remap-add-relative 'default :height 127) ; Change default face size
                ))
      )
" . 9585) ((marker* . 2974) . 9) ((marker . 2974) . -760) ((marker . 1082) . -650) ((marker* . 1197) . 8) ((marker . 1122) . -760) ((marker . 1099) . -668) ((marker) . -668) ((marker) . -668) ((marker) . -760) ((marker*) . 101) ((marker) . -669) ((marker*) . 56) ((marker) . -714) 10235 nil (10343 . 10345) (9585 . 10352) ("    ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
    ;;  '(vterm :build '((\"mkdir -p build\")
    ;;                   (\"cd build\")
    ;;                   (\"cmake ..\")
    ;;                   (\"make\"))
    ;;          ))

    (use-package vterm
      :hook (vterm-mode . (lambda ()
                            (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                            (buffer-face-mode t)))
      :custom
      (vterm-kill-buffer-on-exit nil)
      (vterm-copy-exclude-prompt t)
      (vterm-min-window-width 50)
    :config
  (add-hook 'vterm-mode-hook
          (lambda ()
                  (face-remap-add-relative 'default :height 127) ; Change default face size

      )
" . 9585) ((marker* . 2974) . 102) ((marker) . -670) 10327 (10326 . 10327) 10255 nil (10224 . 10234) (9585 . 10325) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)
    (vterm-min-window-width 50)
  :config
(add-hook 'vterm-mode-hook

                (face-remap-add-relative 'default :height 127) ; Change default face size
    )
" . 9585) ((marker* . 2974) . 97) ((marker . 2974) . -596) ((marker . 1050) . -581) ((marker . 1215) . -595) ((marker . 1065) . -596) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -656) ((marker . 2974) . -581) ((marker . 2974) . -581) ((marker . 2974) . -596) ((marker) . -596) ((marker) . -596) ((marker . 2974) . -596) ((marker . 2974) . -596) 10182 (10181 . 10182) 10181 nil (nil rear-nonsticky nil 10180 . 10181) (nil fontified nil 10166 . 10181) (10166 . 10181) nil (" " . -10166) ((marker) . -1) ("p" . -10167) ((marker) . -1) 10168 (10166 . 10168) (" " . -10166) ((marker) . -1) ("p" . -10167) ((marker) . -1) 10168 (10166 . 10168) (" " . -10166) ((marker) . -1) ("p" . -10167) ((marker) . -1) 10168 (10166 . 10168) ("e" . -10166) ((marker) . -1) ("s" . -10167) ((marker) . -1) ("h" . -10168) ((marker) . -1) ("e" . -10169) ((marker) . -1) 10170 (10165 . 10170) ("e" . -10165) ((marker) . -1) 10166 (10165 . 10166) nil (10155 . 10165) (10155 . 10156) 10213 nil ("
" . -10244) (10154 . 10245) nil (10147 . 10154) (9585 . 10154) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)
    (vterm-min-window-width 50)

    )
" . 9585) ((marker . 2974) . -271) ((marker . 1050) . -271) ((marker . 1215) . -271) ((marker) . -528) 10145 (10144 . 10145) 10113 nil ("
                (face-remap-add-relative 'default :height 127) ; Change default face size
" . 9856) ((marker . 2974) . -90) ((marker . 1050) . -1) ((marker . 1215) . -90) ((marker) . -17) ((marker*) . 74) ((marker) . -18) ((marker*) . 29) ((marker) . -63) (9946 . 9947) nil ("
" . -9946) (9856 . 9947) 9836 nil (72 . 1631) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config
                (face-remap-add-relative 'default :height 127) ; Change default face size
  
    (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
      (setq eshell-history-buffer-when-process-dies t)
      (setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
     :keymaps 'eshell-mode-map
     :stats '(normal visual motion)
     [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
     )
    )
" . 72) ((marker* . 2974) . 506) ((marker . 2974) . -1070) ((marker . 1082) . -978) ((marker* . 1197) . 502) ((marker . 1122) . -1067) ((marker . 1099) . -1070) ((marker . 1050) . -978) ((marker . 1215) . -1040) ((marker . 838) . -97) ((marker . 1065) . -1036) ((marker . 72) . -978) ((marker . 72) . -978) ((marker . 72) . -978) ((marker . 72) . -978) ((marker . 72) . -978) ((marker . 72) . -994) ((marker . 72) . -994) ((marker . 72) . -994) ((marker . 72) . -1036) ((marker . 72) . -1036) ((marker . 72) . -97) ((marker . 72) . -1036) ((marker . 72) . -1036) ((marker . 72) . -97) ((marker . 72) . -1036) ((marker . 72) . -1036) ((marker . 72) . -97) ((marker) . -398) ((marker) . -398) ((marker) . -978) ((marker) . -1323) ((marker) . -1423) ((marker) . -1560) ((marker) . -1036) ((marker) . -1070) ((marker) . -97) ((marker . 72) . -1036) ((marker . 72) . -1036) ((marker . 72) . -97) ((marker) . -1067) ((marker) . -1070) 1050 nil (1134 . 1139) (1113 . 1134) (":" . -1113) ((marker) . -1) 1114 (1112 . 1114) nil (1108 . 1111) ("109" . 1108) ((marker . 72) . -3) ((marker . 72) . -3) ((marker . 72) . -3) ((marker . 72) . -3) ((marker . 72) . -3) ((marker . 72) . -3) (t 24476 36274 145684 538000) nil ("
" . 1050) ((marker . 1050) . -1) nil (nil rear-nonsticky nil 1066 . 1067) ("
" . -1113) (1050 . 1114) nil (72 . 1556) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config


    (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
      (setq eshell-history-buffer-when-process-dies t)
      (setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
     :keymaps 'eshell-mode-map
     :stats '(normal visual motion)
     [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
     )
    )
" . 72) ((marker) . -978) 1051 ("  " . 1050) ((marker) . -2) (1052 . 1053) (72 . 1555) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config

    (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
      (setq eshell-history-buffer-when-process-dies t)
      (setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
     :keymaps 'eshell-mode-map
     :stats '(normal visual motion)
     [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
     )
    )
" . 72) ((marker . 2974) . -2) ((marker) . -984) ((marker . 72) . -2) 1050 (1050 . 1051) 1055 nil (72 . 1552) ("      (use-package esh-mode
        :straight nil
        :hook ((eshell-mode . (lambda () ; UI enhancements
                                (visual-line-mode +1)
                                (set-display-table-slot standard-display-table 0 ?\\ )))
               (eshell-mode . (lambda () ; Text-wrap
                                (set-window-fringes nil 0 0)
                                (set-window-margins nil 1 nil)))
      (eshell-mode . (lambda () (setq-local scroll-margin 3)))
               )
        :custom
        (eshell-kill-processes-on-exit t)
        (eshell-hist-ignoredups t)
        (eshell-scroll-to-bottom-on-input 'all)
        (eshell-scroll-to-bottom-on-output 'all)
        (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
        (eshell-glob-case-insensitive t)
        (eshell-error-if-no-glob t)
        (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
        (eshell-hist-ignoredups t)
        :config
    (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
    (setq eshell-history-buffer-when-process-dies t)
    (setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

        (kb/leader-keys
          \"oE\" '(eshell :which-key \"Open eshell\")
          )

        (general-define-key
          :keymaps 'eshell-mode-map
          :stats '(normal visual motion)
          [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
          )
        )
" . 72) ((marker . 2974) . -1188) ((marker . 1082) . -1131) ((marker* . 1197) . 290) ((marker . 1122) . -1188) ((marker . 1099) . -1135) ((marker) . -1135) ((marker*) . 456) ((marker) . -1136) ((marker*) . 409) ((marker) . -1183) ((marker) . -1135) ((marker) . -1188) 1203 nil (72 . 1663) ("    (use-package esh-mode
      :straight nil
      :hook ((eshell-mode . (lambda () ; UI enhancements
                              (visual-line-mode +1)
                              (set-display-table-slot standard-display-table 0 ?\\ )))
             (eshell-mode . (lambda () ; Text-wrap
                              (set-window-fringes nil 0 0)
                              (set-window-margins nil 1 nil)))
    (eshell-mode . (lambda () (setq-local scroll-margin 3)))
             )
      :custom
      (eshell-kill-processes-on-exit t)
      (eshell-hist-ignoredups t)
      (eshell-scroll-to-bottom-on-input 'all)
      (eshell-scroll-to-bottom-on-output 'all)
      (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
      (eshell-glob-case-insensitive t)
      (eshell-error-if-no-glob t)
      (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
      (eshell-hist-ignoredups t)
      :config
  (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
  (setq eshell-history-buffer-when-process-dies t)
(setq eshell-visual-commands '(\"htop\" \"nvim\"))) ; Commands to run in term buffer to properly display from eshell

      (kb/leader-keys
        \"oE\" '(eshell :which-key \"Open eshell\")
        )

      (general-define-key
        :keymaps 'eshell-mode-map
        :stats '(normal visual motion)
        [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
        )
      )
" . 72) ((marker* . 2974) . 273) ((marker . 2974) . -1250) ((marker . 1082) . -1138) ((marker* . 1197) . 272) ((marker . 1122) . -1250) ((marker . 1099) . -1250) ((marker) . -1250) ((marker) . -1250) ((marker) . -1250) 1322 nil (1304 . 1322) ("e" . -1304) ((marker) . -1) 1305 (1300 . 1305) (1279 . 1300) (1278 . 1279) (1257 . 1278) nil (" " . -1257) ((marker) . -1) 1258 (1256 . 1258) (")" . -1256) ((marker) . -1) ((marker*) . 1) ((marker) . -1) 1257 (1255 . 1257) (1250 . 1255) ("v" . -1250) ((marker) . -1) ("i" . -1251) ((marker) . -1) ("m" . -1252) ((marker) . -1) 1253 (1243 . 1253) ("p" . -1243) ((marker) . -1) 1244 (1229 . 1244) (1228 . 1229) ("a" . -1228) ((marker) . -1) ("l" . -1229) ((marker) . -1) 1230 (1228 . 1230) ("l" . -1228) ((marker) . -1) 1229 (1210 . 1229) (72 . 1483) ("    (use-package esh-mode
      :straight nil
      :hook ((eshell-mode . (lambda () ; UI enhancements
                              (visual-line-mode +1)
                              (set-display-table-slot standard-display-table 0 ?\\ )))
             (eshell-mode . (lambda () ; Text-wrap
                              (set-window-fringes nil 0 0)
                              (set-window-margins nil 1 nil)))
    (eshell-mode . (lambda () (setq-local scroll-margin 3)))
             )
      :custom
      (eshell-kill-processes-on-exit t)
      (eshell-hist-ignoredups t)
      (eshell-scroll-to-bottom-on-input 'all)
      (eshell-scroll-to-bottom-on-output 'all)
      (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
      (eshell-glob-case-insensitive t)
      (eshell-error-if-no-glob t)
      (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
      (eshell-hist-ignoredups t)
      :config
  (with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded
  (setq eshell-history-buffer-when-process-dies t)

  
      (kb/leader-keys
        \"oE\" '(eshell :which-key \"Open eshell\")
        )

      (general-define-key
        :keymaps 'eshell-mode-map
        :stats '(normal visual motion)
        [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
        )
      )
" . 72) ((marker . 72) . -1096) ((marker* . 2974) . 318) ((marker . 2974) . -980) ((marker . 72) . -1096) ((marker . 72) . -1096) ((marker . 72) . -1096) ((marker . 72) . -1096) ((marker . 72) . -1096) ((marker . 72) . -62) ((marker . 72) . -119) ((marker . 72) . -62) ((marker . 72) . -62) ((marker . 72) . -62) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -980) ((marker . 72) . -1103) ((marker . 72) . -1103) ((marker . 72) . -1103) ((marker . 838) . -103) ((marker . 1065) . -1103) ((marker . 72) . -1103) ((marker . 72) . -1103) ((marker . 72) . -103) ((marker . 72) . -1103) ((marker . 72) . -1103) ((marker . 72) . -103) ((marker . 72) . -1103) ((marker . 72) . -1103) ((marker . 72) . -103) ((marker) . -103) ((marker) . -1103) ((marker) . -1103) 1210 (1209 . 1210) 1175 nil (1166 . 1167) nil 1208 nil (1203 . 1208) (1182 . 1203) (1161 . 1182) (72 . 1436) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
  (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config
(with-eval-after-load 'esh-opt ; An eshell module that needs to be loaded

  
    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
      :keymaps 'eshell-mode-map
      :stats '(normal visual motion)
      [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
      )
    )
" . 72) ((marker) . -1042) 1115 (1114 . 1115) (1108 . 1114) (1087 . 1108) ("e" . -1087) ((marker) . -1) 1088 (1074 . 1088) ("O" . -1074) ((marker) . -1) 1075 (1072 . 1075) ("(" . -1072) ((marker) . -1) 1073 (1062 . 1073) (1055 . 1062) ("r" . -1055) ((marker) . -1) 1056 (1041 . 1056) (72 . 1298) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
  (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config


    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
      :keymaps 'eshell-mode-map
      :stats '(normal visual motion)
      [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
      )
    )
" . 72) ((marker) . -969) 1042 ("  " . 1041) ((marker) . -2) (1043 . 1044) (72 . 1297) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
  (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
      :keymaps 'eshell-mode-map
      :stats '(normal visual motion)
      [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
      )
    )
" . 72) ((marker . 72) . -551) ((marker . 72) . -551) ((marker . 72) . -551) ((marker . 72) . -1138) ((marker . 72) . -1138) ((marker . 72) . -1138) ((marker . 1) . -1138) ((marker) . -957) 1041 (1040 . 1041) 1029 nil ("    :config
" . 8931) ((marker) . -11) 8942 nil ("
" . 8713) nil (8646 . 8950) ("      (use-package fish-completion
        :hook (eshell-mode . (lambda ()

        (when (and (executable-find \"fish\")
                   (require 'fish-completion nil t))
          (fish-completion-mode))
        ))
        :config
        )
" . 8646) ((marker) . -49) ((marker* . 2974) . 28) ((marker . 2974) . -216) ((marker . 1082) . -35) ((marker* . 1197) . 26) ((marker . 1122) . -216) ((marker . 1099) . -49) ((marker*) . 195) ((marker) . -50) ((marker*) . 28) ((marker) . -217) ((marker . 2974) . -216) ((marker . 2974) . -49) ((marker) . -49) ((marker) . -216) ((marker . 2974) . -216) 8681 nil ("-" . 8830) nil ("global" . 8830) nil (8868 . 8869) (8646 . 8896) ("    (use-package fish-completion
      :hook (eshell-mode . (lambda ()

      (when (and (executable-find \"fish\")
                 (require 'fish-completion nil t))
        (global-fish-completion-mode))
)
      :config
      )
" . 8646) ((marker) . -203) ((marker* . 2974) . 23) ((marker . 2974) . -78) ((marker . 1082) . -71) ((marker* . 1197) . 22) ((marker . 1122) . -71) ((marker . 1099) . -71) ((marker . 1050) . -72) ((marker . 1215) . -203) ((marker . 2974) . -202) ((marker . 2974) . -78) ((marker*) . 26) ((marker) . -203) ((marker*) . 150) ((marker) . -79) 8850 (8849 . 8850) nil (8849 . 8850) nil (nil rear-nonsticky nil 8723 . 8724) (8718 . 8850) 8768 (8717 . 8718) ("                             fish-completion-mode)
" . 8717) ((marker* . 2974) . 22) ((marker . 2974) . -51) 8768 nil ("      (when (and (executable-find \"fish\")
                 (require 'fish-completion nil t))
        (global-fish-completion-mode))
" . 8782) ((marker) . -122) ((marker . 2974) . -122) ((marker . 1122) . -29) ((marker . 1099) . -122) ((marker) . -29) ((marker) . -122) 8904 nil (8646 . 8922) ("  (use-package fish-completion
    :hook (eshell-mode . (lambda ()
fish-completion-mode)
    :config
    (when (and (executable-find \"fish\")
               (require 'fish-completion nil t))
      (global-fish-completion-mode))
    )
" . 8646) ((marker) . -66) ((marker*) . 168) ((marker) . -66) ((marker*) . 169) ((marker) . -65) 8713 (8712 . 8713) (8706 . 8712) ("d" . -8706) ((marker) . -1) 8707 (8702 . 8707) (t 24473 41648 610918 291000) nil (9179 . 9745) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)
  (vterm-min-window-width 50)
    )
" . 9179) 9719 nil (9735 . 9736) nil (9732 . 9735) nil (nil rear-nonsticky nil 9731 . 9732) (nil fontified nil 9710 . 9732) (9710 . 9732) nil (9709 . 9710) (9179 . 9716) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)

    )
" . 9179) 9707 (9706 . 9707) (t 24473 41082 124153 938000) 9680 nil (6964 . 7489) ("  (use-package eshell-toggle
    :custom
    (eshell-toggle-size-fraction 3) ; How big is the window?
    ;; (eshell-toggle-use-projectile-root t)
    (eshell-toggle-use-git-root t)
    (eshell-toggle-init-function #'eshell-toggle-init-eshell) ; Terminal emulator to use
    (eshell-toggle-run-command nil) ; Command to run in new buffer
  (eshell-toggle-window-side 'above)
    :config

    (kb/leader-keys
      \"oe\" '(eshell-toggle :which-key \"Toggle eshell\")
      \"oE\" '(eshell :which-key \"Open eshell\")
      )
    )
" . 6964) 7338 nil (7337 . 7338) nil (7333 . 7337) ("v" . -7333) ("o" . -7334) 7335 (7330 . 7335) (":" . -7330) 7331 (7304 . 7305) nil 7330 nil (nil rear-nonsticky nil 7329 . 7330) (nil fontified nil 7304 . 7330) (7304 . 7330) nil (6964 . 7453) ("  (use-package eshell-toggle
    :custom
    (eshell-toggle-size-fraction 3) ; How big is the window?
    ;; (eshell-toggle-use-projectile-root t)
    (eshell-toggle-use-git-root t)
    (eshell-toggle-init-function #'eshell-toggle-init-eshell) ; Terminal emulator to use
    (eshell-toggle-run-command nil) ; Command to run in new buffer

    :config

    (kb/leader-keys
      \"oe\" '(eshell-toggle :which-key \"Toggle eshell\")
      \"oE\" '(eshell :which-key \"Open eshell\")
      )
    )
" . 6964) 7302 (7301 . 7302) (t 24473 41027 294759 314000) 7283 nil (7381 . 7382) ("E" . 7381) nil (7426 . 7428) ("E" . 7426) (" " . 7426) (7422 . 7426) ("Toggle" . 7422) nil ("-toggle" . 7409) nil (7398 . 7399) ("e" . 7398) nil (nil rear-nonsticky nil 7395 . 7396) ("
" . -7444) (7389 . 7445) 7343 (t 24473 40999 478396 744000) nil (6875 . 7414) ("* Eshell-toggle

Toggle eshell window in bottom of current buffer
#+BEGIN_SRC emacs-lisp
  (use-package eshell-toggle
    :custom
    (eshell-toggle-size-fraction 3) ; How big is the window?
    ;; (eshell-toggle-use-projectile-root t)
    (eshell-toggle-use-git-root t)
    (eshell-toggle-init-function #'eshell-toggle-init-eshell) ; Terminal emulator to use
    (eshell-toggle-run-command nil) ; Command to run in new buffer
    :config

    (kb/leader-keys
      \"oe\" '(eshell-toggle :which-key \"Toggle Eshell\")
      )
    )
#+END_SRC
" . 7023) 7032 nil (7023 . 7562) ("* Eshell-toggle

Toggle eshell window in bottom of current buffer
#+BEGIN_SRC emacs-lisp
  (use-package eshell-toggle
    :custom
    (eshell-toggle-size-fraction 3) ; How big is the window?
    ;; (eshell-toggle-use-projectile-root t)
    (eshell-toggle-use-git-root t)
    (eshell-toggle-init-function #'eshell-toggle-init-eshell) ; Terminal emulator to use
    (eshell-toggle-run-command nil) ; Command to run in new buffer
    :config

    (kb/leader-keys
      \"oe\" '(eshell-toggle :which-key \"Toggle Eshell\")
      )
    )
#+END_SRC
" . 7120) 7129 nil (7120 . 7659) ("* Eshell-toggle

Toggle eshell window in bottom of current buffer
#+BEGIN_SRC emacs-lisp
  (use-package eshell-toggle
    :custom
    (eshell-toggle-size-fraction 3) ; How big is the window?
    ;; (eshell-toggle-use-projectile-root t)
    (eshell-toggle-use-git-root t)
    (eshell-toggle-init-function #'eshell-toggle-init-eshell) ; Terminal emulator to use
    (eshell-toggle-run-command nil) ; Command to run in new buffer
    :config

    (kb/leader-keys
      \"oe\" '(eshell-toggle :which-key \"Toggle Eshell\")
      )
    )
#+END_SRC
" . 7221) 7230 nil (nil line-prefix "*" 7222 . 7223) (nil wrap-prefix "*** " 7222 . 7223) (nil fontified t 7222 . 7223) (nil face org-level-2 7222 . 7223) (nil line-prefix "*" 7221 . 7222) (nil wrap-prefix "*** " 7221 . 7222) (nil fontified t 7221 . 7222) (nil face (org-superstar-header-bullet org-level-2) 7221 . 7222) (nil composition (3 1 [nil]) 7221 . 7222) ("** " . 7221) (7224 . 7226) 7231 nil (nil line-prefix "**" 7223 . 7224) (nil wrap-prefix "***** " 7223 . 7224) (nil fontified t 7223 . 7224) (nil face org-level-3 7223 . 7224) (nil line-prefix "**" 7222 . 7223) (nil wrap-prefix "***** " 7222 . 7223) (nil fontified t 7222 . 7223) (nil face (org-superstar-header-bullet org-level-3) 7222 . 7223) (nil composition (1 1 [nil]) 7222 . 7223) (nil line-prefix "**" 7221 . 7222) (nil wrap-prefix "***** " 7221 . 7222) (nil fontified t 7221 . 7222) (nil face org-hide 7221 . 7222) ("*** " . 7221) (7225 . 7228) 7232 nil (nil line-prefix "***" 7224 . 7225) (nil wrap-prefix "******* " 7224 . 7225) (nil fontified t 7224 . 7225) (nil face org-level-4 7224 . 7225) (nil line-prefix "***" 7223 . 7224) (nil wrap-prefix "******* " 7223 . 7224) (nil fontified t 7223 . 7224) (nil face (org-superstar-header-bullet org-level-4) 7223 . 7224) (nil composition (6 1 [nil]) 7223 . 7224) (nil line-prefix "***" 7221 . 7223) (nil wrap-prefix "******* " 7221 . 7223) (nil fontified t 7221 . 7223) (nil face org-hide 7221 . 7223) ("**** " . 7221) (7226 . 7230) 7233 nil (nil line-prefix "**" 7225 . 7226) (nil wrap-prefix "***** " 7225 . 7226) (nil fontified t 7225 . 7226) (nil face org-level-3 7225 . 7226) (nil line-prefix "**" 7224 . 7225) (nil wrap-prefix "***** " 7224 . 7225) (nil fontified t 7224 . 7225) (nil face (org-superstar-header-bullet org-level-3) 7224 . 7225) (nil composition (1 1 [nil]) 7224 . 7225) (nil line-prefix "**" 7222 . 7224) (nil wrap-prefix "***** " 7222 . 7224) (nil fontified t 7222 . 7224) (nil face org-hide 7222 . 7224) ("*** " . 7221) (7225 . 7230) 7232 nil (nil line-prefix "*" 7224 . 7225) (nil wrap-prefix "*** " 7224 . 7225) (nil fontified t 7224 . 7225) (nil face org-level-2 7224 . 7225) (nil line-prefix "*" 7223 . 7224) (nil wrap-prefix "*** " 7223 . 7224) (nil fontified t 7223 . 7224) (nil face (org-superstar-header-bullet org-level-2) 7223 . 7224) (nil composition (3 1 [nil]) 7223 . 7224) (nil line-prefix "*" 7222 . 7223) (nil wrap-prefix "*** " 7222 . 7223) (nil fontified t 7222 . 7223) (nil face org-hide 7222 . 7223) ("** " . 7221) (7224 . 7228) 7231 nil (nil fontified t 7223 . 7224) (t 24473 37301 737502 251000) (nil line-prefix "" 7223 . 7224) (t 24473 37301 737502 251000) (nil wrap-prefix "* " 7223 . 7224) (t 24473 37301 737502 251000) (nil face org-level-1 7223 . 7224) (t 24473 37301 737502 251000) (nil fontified t 7222 . 7223) (t 24473 37301 737502 251000) (nil line-prefix "" 7222 . 7223) (t 24473 37301 737502 251000) (nil wrap-prefix "* " 7222 . 7223) (t 24473 37301 737502 251000) (nil face (org-superstar-header-bullet org-level-1) 7222 . 7223) (t 24473 37301 737502 251000) (nil composition (0 1 [nil]) 7222 . 7223) (t 24473 37301 737502 251000) ("* " . 7221) (t 24473 37301 737502 251000) (7223 . 7226) 7230 (t 24473 37301 737502 251000) nil (9706 . 10196) ("  (use-package vterm-toggle
    :config
    (kb/leader-keys
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
     \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
     \"vd\" '(vterm-toggle-insert-cd :which-key \"Cd to current buffer dir\")
     )

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9706) 9766 nil (9765 . 9766) (9765 . 9770) (" " . 9765) nil (9765 . 9766) ("     " . 9765) ("
" . -9765) nil ("    :config
" . 9622) nil ("    (set-face-attribute 'vterm-color-default nil :foreground \"#ABB2BF\")
" . 9634) 9659 (t 24473 37260 628044 40000) nil ("remap-" . 9639) nil (9639 . 9663) ("face-remap" . 9639) ("-add-relative" . 9649) (t 24473 37092 336917 297000) nil (9649 . 9662) (9639 . 9649) ("remap-set-face-attribute" . 9639) nil (9639 . 9645) (t 24473 36906 425993 981000) nil (9703 . 9704) (9695 . 9696) nil (nil rear-nonsticky nil 9701 . 9702) (nil fontified nil 9695 . 9702) (9695 . 9702) 9713 ("'vterm-color-white" . 9695) 9713 (t 24473 36851 296701 401000) nil (9094 . 9721) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)
:config
(set-face-attribute 'vterm-color-default nil :foreground 'vterm-color-white)
    )
" . 9094) 9622 nil (9705 . 9706) ("\"" . -9705) 9706 (9693 . 9706) ("c" . -9693) ("o" . -9694) 9695 (9689 . 9695) ("e" . -9689) 9690 (9686 . 9690) ("'" . -9686) ("v" . -9687) 9688 (9686 . 9688) (t 24473 36821 537081 643000) (" " . -9686) (9669 . 9687) ("n" . -9669) ("i" . -9670) ("l" . -9671) 9672 (9669 . 9672) ("t" . -9669) 9670 (9656 . 9670) (t 24473 36809 137239 718000) (9649 . 9656) ("'" . 9649) nil (9649 . 9650) (t 24473 36798 587374 36000) (" " . -9649) (9647 . 9650) ("d" . -9647) ("e" . -9648) 9649 (9638 . 9649) ("t" . -9638) 9639 (9630 . 9639) nil (9627 . 9628) nil (9622 . 9628) (t 24473 36602 783166 936000) nil ("  " . -9623) (9094 . 9632) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)


    )
" . 9094) 9623 ("  " . 9622) (9624 . 9625) (9094 . 9631) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    :hook (vterm-mode . (lambda ()
                          (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                          (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)

    )
" . 9094) 9622 (9621 . 9622) (t 24473 36576 293494 22000) 9603 nil (9094 . 9628) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
  :hook (vterm-mode . (lambda ()
            (set (make-local-variable 'buffer-face-mode-face) 'fixed-pitch)
                 (buffer-face-mode t)))
    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)
    )
" . 9094) 9366 (t 24473 36571 906881 370000) nil (nil rear-nonsticky nil 9513 . 9514) (nil fontified nil 9475 . 9514) (nil fontified nil 9399 . 9475) (nil fontified nil 9388 . 9399) (9388 . 9514) nil (9380 . 9388) (t 24473 36566 763611 313000) (9375 . 9380) (t 24473 36563 123656 57000) (9368 . 9375) (9094 . 9457) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm

    :custom
    (vterm-kill-buffer-on-exit nil)
    (vterm-copy-exclude-prompt t)
    )
" . 9094) 9366 (9365 . 9366) (t 24473 36514 950911 925000) 9365 nil (9498 . 9508) (9481 . 9498) (9481 . 9482) (t 24473 36336 53043 655000) nil ("  (general-define-key
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" nil
     \"vn\" nil
     \"vd\" nil
     )
" . 9843) 9980 (t 24473 36313 766635 238000) nil (9970 . 9973) ("'(vterm-toggle-insert-cd :which-key \"Cd to current buffer dir\")" . 9970) nil (9956 . 9959) ("'(vterm-toggle-forward :which-key \"Prev vterm buffer\")" . 9956) nil (9942 . 9945) ("'(vterm-toggle-backward :which-key \"Prev vterm buffer\")" . 9942) nil (9504 . 10289) ("  (use-package vterm-toggle
    :config
    (kb/leader-keys
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
     \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
     \"vd\" '(vterm-toggle-insert-cd :which-key \"Cd to current buffer dir\")
     )
  (general-define-key
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
     \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
     \"vd\" '(vterm-toggle-insert-cd :which-key \"Cd to current buffer dir\")
     )
 
    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 9942 nil (nil rear-nonsticky nil 9869 . 9870) ("
" . -10143) (9864 . 10144) 9844 nil (9504 . 10011) ("  (use-package vterm-toggle
    :config
    (kb/leader-keys
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
     \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
     \"vd\" '(vterm-toggle-insert-cd :which-key \"Cd to current buffer dir\")
     )
  (general-define-key

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 9865 (9864 . 9865) ("
" . 9864) (9862 . 9864) ("y" . -9862) 9863 (9853 . 9863) (9846 . 9853) ("g" . -9846) ("e" . -9847) 9848 (9845 . 9848) (9504 . 9991) ("  (use-package vterm-toggle
    :config
    (kb/leader-keys
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
     \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
     \"vd\" '(vterm-toggle-insert-cd :which-key \"Cd to current buffer dir\")
     )


    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 9843 (9842 . 9843) 9842 nil (nil rear-nonsticky nil 9795 . 9796) (nil fontified nil 9774 . 9796) (9774 . 9796) 9795 ("vterm-toggle-insert-c" . 9774) 9795 nil (9549 . 9563) nil ("general-define-key" . 9549) (t 24473 36116 68834 28000) nil (9504 . 9991) ("  (use-package vterm-toggle
    :config
      (general-define-key
       :keymaps 'vterm-mode-map
       :states '(normal motion visual)
       \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
       \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
       \"vd\" '(vterm-toggle-insert-c :which-key \"Cd to current buffer dir\")
       )

      (kb/leader-keys
        \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
        \"oT\" '(vterm :which-key \"Vterm in current window\")
        )
      )
" . 9504) 9544 nil ("    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

" . 9544) (t 24473 36091 472427 345000) nil ("
    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #

                                          ;Switch to next vterm buffer
                                          ;Switch to previous vterm buffer
" . 9629) (t 24473 36068 119383 182000) nil (9504 . 10447) ("  (use-package vterm-toggle
    :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #

                                          ;Switch to next vterm buffer
                                          ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"vp\" '(vterm-toggle-backward :which-key \"Prev vterm buffer\")
     \"vn\" '(vterm-toggle-forward :which-key \"Prev vterm buffer\")
   \"vd\" '(vterm-toggle-insert-c :which-key \"Cd to current buffer dir\")
     )

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 10067 nil (10073 . 10075) ("s-p" . 10073) 10075 nil (10141 . 10142) ("p" . -10141) 10142 (10140 . 10142) ("-n" . 10140) nil ("s" . 10140) nil (10204 . 10206) (t 24473 36028 453296 950000) nil (10265 . 10266) (10250 . 10265) ("c" . -10250) 10251 (10242 . 10251) nil (10243 . 10244) (10229 . 10243) nil (10207 . 10208) nil (nil rear-nonsticky nil 10198 . 10199) (nil fontified nil 10168 . 10199) (10168 . 10199) nil (10167 . 10168) nil (10146 . 10147) nil (10114 . 10118) ("Next" . 10114) nil (10114 . 10133) ("n" . -10114) ("e" . -10115) 10116 (10101 . 10116) (10079 . 10080) (t 24473 35961 547615 99000) nil (10137 . 10141) ("'" . 10137) nil 10159 nil ("d" . 10159) (")" . 10160) 10161 nil (nil rear-nonsticky nil 10160 . 10161) (nil fontified nil 10137 . 10161) (10137 . 10161) nil (9504 . 10290) ("  (use-package vterm-toggle
    :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #

                                          ;Switch to next vterm buffer
                                          ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map
     :states '(normal motion visual)
     \"s-p\" 'vterm-toggle-backward
     \"s-n\" 'vterm-toggle-forward

     )

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 10134 (10133 . 10134) 10133 nil ("'vterm-toggle-insert-cd)" . 9827) (t 24473 35935 871328 474000) nil (9504 . 10310) ("  (use-package vterm-toggle
    :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

                                          ;Switch to next vterm buffer
                                          ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map
   :states '(normal motion visual)
     \"s-p\" 'vterm-toggle-backward
     \"s-n\" 'vterm-toggle-forward
     )

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 10087 nil (10074 . 10087) (10067 . 10074) (10065 . 10068) ("\"" . -10065) 10066 (10057 . 10066) (9504 . 10277) ("  (use-package vterm-toggle
    :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

                                          ;Switch to next vterm buffer
                                          ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map

     \"s-p\" 'vterm-toggle-backward
     \"s-n\" 'vterm-toggle-forward
     )

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 10054 (10053 . 10054) (t 24473 35916 931609 610000) 10028 nil (9504 . 10273) ("    (use-package vterm-toggle
      :config
      (global-set-key [f2] 'vterm-toggle)
      (global-set-key [C-f2] 'vterm-toggle-cd)

      ;; you can cd to the directory where your previous buffer file exists
      ;; after you have toggle to the vterm buffer with `vterm-toggle'.
      (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

                                            ;Switch to next vterm buffer
                                            ;Switch to previous vterm buffer

      (general-define-key
       :keymaps 'vterm-mode-map
       \"s-p\" 'vterm-toggle-backward
      \"s-n\" 'vterm-toggle-forward
       )

      (kb/leader-keys
        \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
        \"oT\" '(vterm :which-key \"Vterm in current window\")
        )
      )
" . 9504) 10076 nil (")" . 10145) 10146 (t 24473 35903 115148 477000) nil (10123 . 10124) nil (")   " . 10123) nil ("(kbd " . 10118) nil ("vterm-mode-map " . 10118) nil ("key " . 10118) nil ("-" . 10118) nil ("define" . 10118) nil ("(" . 10118) (t 24473 35891 808650 295000) nil (nil rear-nonsticky nil 10117 . 10118) ("
" . -10181) (10111 . 10182) 10076 nil ("      (define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
" . 9940) 9987 nil (9504 . 10346) ("  (use-package vterm-toggle
    :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

                                          ;Switch to next vterm buffer
    (define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
                                          ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map
     \"s-p\" 'vterm-toggle-backward
)

    (kb/leader-keys
      \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
      \"oT\" '(vterm :which-key \"Vterm in current window\")
      )
    )
" . 9504) 10156 (10155 . 10156) (t 24473 35872 772267 903000) nil (9504 . 10302) ("        (use-package vterm-toggle
      :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

    ;Switch to next vterm buffer
    (define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
    ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map
     \"s-p\" 'vterm-toggle-backward)

  (kb/leader-keys
  \"ot\" '(vterm-toggle :which-key \"Vterm-toggle\")
  \"oT\" '(vterm :which-key \"Vterm in current window\")
)
        )
" . 9504) 10157 nil (10210 . 10211) (10209 . 10210) 10207 nil (10189 . 10207) ("-toggle" . 10189) nil ("-toggle" . 10171) nil (10161 . 10162) ("t" . 10161) nil (nil rear-nonsticky nil 10158 . 10159) ("
" . -10205) (10156 . 10206) nil (10136 . 10156) (10131 . 10136) ("W" . -10131) ("h" . -10132) ("i" . -10133) ("c" . -10134) ("h" . -10135) ("-" . -10136) ("k" . -10137) 10138 (10130 . 10138) ("\"" . -10130) 10131 (10130 . 10131) ("'" . -10130) ("T" . -10131) ("o" . -10132) 10133 (10130 . 10133) ("\"" . -10130) 10131 (10117 . 10131) ("e" . -10117) ("s" . -10118) 10119 (10116 . 10119) (10114 . 10116) nil (10110 . 10114) (9504 . 10121) ("      (use-package vterm-toggle
    :config
  (global-set-key [f2] 'vterm-toggle)
  (global-set-key [C-f2] 'vterm-toggle-cd)

  ;; you can cd to the directory where your previous buffer file exists
  ;; after you have toggle to the vterm buffer with `vterm-toggle'.
  (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

  ;Switch to next vterm buffer
  (define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
  ;Switch to previous vterm buffer

  (general-define-key
   :keymaps 'vterm-mode-map
   \"s-p\" 'vterm-toggle-backward)

(kb/leader-keys

      )
" . 9504) 10080 (10079 . 10080) (10074 . 10079) ("/" . -10074) 10075 (10072 . 10075) nil (nil rear-nonsticky nil 10063 . 10064) ("
" . -10072) (10063 . 10073) nil ("(kb/lead
" . 9979) 9987 nil (9979 . 9987) (9979 . 9980) (9504 . 10072) ("        (use-package vterm-toggle
      :config
    (global-set-key [f2] 'vterm-toggle)
    (global-set-key [C-f2] 'vterm-toggle-cd)

    ;; you can cd to the directory where your previous buffer file exists
    ;; after you have toggle to the vterm buffer with `vterm-toggle'.
    (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

    ;Switch to next vterm buffer
    (define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
    ;Switch to previous vterm buffer

    (general-define-key
     :keymaps 'vterm-mode-map
     \"s-p\" 'vterm-toggle-backward)

        )
" . 9504) 9999 (9999 . 10000) 10022 (t 24473 35800 906681 726000) nil (10063 . 10064) nil ("   " . 10063) nil (")" . 10063) nil (" " . 10058) ("d" . 10058) ("b" . 10058) ("k" . 10058) nil ("(" . 10058) nil (9504 . 10107) ("      (use-package vterm-toggle
    :config
  (global-set-key [f2] 'vterm-toggle)
  (global-set-key [C-f2] 'vterm-toggle-cd)

  ;; you can cd to the directory where your previous buffer file exists
  ;; after you have toggle to the vterm buffer with `vterm-toggle'.
  (define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

  ;Switch to next vterm buffer
  (define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
  ;Switch to previous vterm buffer
  (general-define-key
   :keymaps 'vterm-mode-map
(kbd \"s-p\")   'vterm-toggle-backward)

      )
" . 9504) 10029 (" " . 10028) (10029 . 10030) nil (10004 . 10014) (9504 . 10066) ("    (use-package vterm-toggle
  :config
(global-set-key [f2] 'vterm-toggle)
(global-set-key [C-f2] 'vterm-toggle-cd)

;; you can cd to the directory where your previous buffer file exists
;; after you have toggle to the vterm buffer with `vterm-toggle'.
(define-key vterm-mode-map [(control return)]   #'vterm-toggle-insert-cd)

;Switch to next vterm buffer
(define-key vterm-mode-map (kbd \"s-n\")   'vterm-toggle-forward)
;Switch to previous vterm buffer
(general-define-key
vterm-mode-map (kbd \"s-p\")   'vterm-toggle-backward)

    )
" . 9504) 9979 (" " . 9978) (9979 . 9980) nil (9967 . 9968) (9960 . 9967) (t 24473 35757 214011 471000) nil (nil rear-nonsticky nil 10023 . 10024) (nil fontified nil 9959 . 10024) (nil fontified nil 9926 . 9959) (nil fontified nil 9862 . 9926) (nil fontified nil 9833 . 9862) (nil fontified nil 9832 . 9833) (nil fontified nil 9758 . 9832) (nil fontified nil 9692 . 9758) (nil fontified nil 9622 . 9692) (nil fontified nil 9621 . 9622) (nil fontified nil 9580 . 9621) (nil fontified nil 9544 . 9580) (9544 . 10024) nil (9504 . 9551) ("  (use-package vterm-toggle
:config

  )
" . 9504) 9540 (9539 . 9540) (9532 . 9539) (t 24473 35738 737626 731000) nil (9535 . 9536) ("/" . -9535) 9536 (9535 . 9536) (9504 . 9536) ("  (use-package vterm-toggle


" . 9504) 9533 ("  " . 9532) (9534 . 9535) (9504 . 9535) ("(use-package vterm-toggle

" . 9504) 9530 (9529 . 9530) (9525 . 9529) (9504 . 9525) (t 24473 35631 509282 962000) nil ("U" . -9504) ("s" . -9505) ("e" . -9506) 9507 (9504 . 9507) nil (9481 . 9514) ("<el" . -9481) 9484 (9481 . 9484) (9480 . 9481) (9479 . 9480) 9479 nil (9474 . 9479) ("i" . -9474) ("b" . -9475) ("g" . -9476) ("g" . -9477) 9478 (9472 . 9478) (9468 . 9472) ("e" . -9468) 9469 (9467 . 9469) nil (9463 . 9467) 9387 (t 24473 34802 587767 728000) nil (9094 . 9454) ("      ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
      ;;  '(vterm :build '((\"mkdir -p build\")
      ;;                   (\"cd build\")
      ;;                   (\"cmake ..\")
      ;;                   (\"make\"))
      ;;          ))

      (use-package vterm
      :custom
  (vterm-kill-buffer-on-exit nil)
(vterm-copy-exclude-prompt t)
      )
" . 9094) 9408 nil ("
" . 9472) (t 24473 34754 228891 268000) nil (9468 . 9471) nil (nil rear-nonsticky nil 9468 . 9469) (nil fontified nil 9443 . 9469) (9443 . 9469) nil (9442 . 9443) nil (9094 . 9451) ("    ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
    ;;  '(vterm :build '((\"mkdir -p build\")
    ;;                   (\"cd build\")
    ;;                   (\"cmake ..\")
    ;;                   (\"make\"))
    ;;          ))

    (use-package vterm
    :custom
(vterm-kill-buffer-on-exit nil)

    )
" . 9094) 9424 (9423 . 9424) (t 24473 34708 629991 831000) 9423 nil (9418 . 9423) nil (9392 . 9393) nil 9417 nil (nil rear-nonsticky nil 9416 . 9417) (nil fontified nil 9392 . 9417) (9392 . 9417) nil (9094 . 9399) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
  :custom

)
" . 9094) 9377 ("  " . 9376) (9378 . 9379) (9094 . 9380) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
  :custom
    )
" . 9094) 9376 (9375 . 9376) ("
" . 9375) (9372 . 9375) ("o" . -9372) ("t" . -9373) ("m" . -9374) 9375 (9368 . 9375) (9094 . 9375) ("    ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
    ;;  '(vterm :build '((\"mkdir -p build\")
    ;;                   (\"cd build\")
    ;;                   (\"cmake ..\")
    ;;                   (\"make\"))
    ;;          ))

    (use-package vterm

      )
" . 9094) 9380 (9379 . 9380) (9094 . 9388) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
)
" . 9094) 9366 (9365 . 9366) (t 24473 34338 94305 626000) nil (9094 . 9367) ("  (straight-use-package ; This doesn't work, so I have to do this manually for now
   '(vterm :build '((\"mkdir -p build\")
                    (\"cd build\")
                    (\"cmake ..\")
                    (\"make\"))
           ))

  (use-package vterm)
" . 9094) 9326 (t 24473 34312 1927 569000) nil (9347 . 9348) nil ("    )
" . 9348) 9353 (t 24473 34303 392249 530000) nil ("    :build '((\"mkdir -p build\")
             (\"cd build\")
             (\"cmake ..\")
             (\"make\"))
" . 9348) 9353 (t 24473 34245 374511 772000) nil (9094 . 9461) ("  (straight-use-package ; This doesn't work, so I have to do this manually for now
   '(vterm :build '((\"mkdir -p build\")
                    (\"cd build\")
                    (\"cmake ..\")
                    (\"make\"))
           ))

  (use-package vterm
  :build '((\"mkdir -p build\")
                    (\"cd build\")
                    (\"cmake ..\")
                    (\"make\"))
    )
" . 9094) 9327 nil ("           )
" . 9474) 9485 nil ("(vterm " . 9350) nil (nil rear-nonsticky nil 9492 . 9493) (nil fontified nil 9481 . 9493) (nil fontified nil 9451 . 9481) (nil fontified nil 9418 . 9451) (nil fontified nil 9385 . 9418) (nil fontified nil 9350 . 9385) (9350 . 9493) nil (9094 . 9357) ("  (straight-use-package ; This doesn't work, so I have to do this manually for now
   '(vterm :build '((\"mkdir -p build\")
                    (\"cd build\")
                    (\"cmake ..\")
                    (\"make\"))
           ))

  (use-package vterm

    )
" . 9094) 9348 (9347 . 9348) 9331 nil (9094 . 9354) ("  ;; (straight-use-package ; This doesn't work, so I have to do this manually for now
  ;;  '(vterm :build '((\"mkdir -p build\")
  ;;                   (\"cd build\")
  ;;                   (\"cmake ..\")
  ;;                   (\"make\"))
  ;;          ))

  (use-package vterm
    )
" . 9094) 9344 (t 24473 34214 755775 20000) nil (985 . 986) (t 24473 34201 679663 436000) nil (1 . 9381) 9041 ("#+TITLE: Shell configuration


* Eshell itself

#+BEGIN_SRC emacs-lisp
  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
  (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan (◠﹏◠✿)\\n\")
    (eshell-hist-ignoredups t)
    :config
    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (kb/leader-keys
      :keymaps 'eshell-mode-map
      :stats '(normal visual motion)
      [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
      )
    )
#+END_SRC

Make it fancy
#+BEGIN_SRC emacs-lisp
;; Go to https://github.com/daviwil/dotfiles/blob/master/Emacs.org#better-colors
#+END_SRC
** My own Eshell prompt

Entirely taken from [[http://www.modernemacs.com/post/custom-eshell/][Making eshell your own | Modern Emacs]]
#+BEGIN_SRC emacs-lisp
  (require 'dash)
  (require 's)

  (defmacro with-face (STR &rest PROPS)
    \"Return STR propertized with PROPS.\"
    `(propertize ,STR 'face (list ,@PROPS)))

  (defmacro esh-section (NAME ICON FORM &rest PROPS)
    \"Build eshell section NAME with ICON prepended to evaled FORM with PROPS.\"
    `(setq ,NAME
           (lambda () (when ,FORM
                        (-> ,ICON
                            (concat esh-section-delim ,FORM)
                            (with-face ,@PROPS))))))

  (defun esh-acc (acc x)
    \"Accumulator for evaluating and concatenating esh-sections.\"
    (--if-let (funcall x)
        (if (s-blank? acc)
            it
          (concat acc esh-sep it))
      acc))

  (defun esh-prompt-func ()
    \"Build `eshell-prompt-function'\"
    (concat esh-header
            (-reduce-from 'esh-acc \"\" eshell-funcs)
            \"\\n\"
            eshell-prompt-string))

  ;; Separator between esh-sections
  (setq esh-sep \" | \")  ; or \" | \"

  ;; Separator between an esh-section icon and form
  (setq esh-section-delim \" \")

  ;; Eshell prompt header
  (setq esh-header \"\\n┌─\")  ; or \"\\n┌─\"

  ;; Eshell prompt regexp and string. Unless you are varying the prompt by eg.
  ;; your login, these can be the same.
  (setq eshell-prompt-regexp \"└─> λ \")   ; or \"└─> \"
  (setq eshell-prompt-string \"└─> λ \")   ; or \"└─> \"

  (esh-section esh-dir
               \" \\xf07c \"  ;  (faicon folder)
               (abbreviate-file-name (eshell/pwd))
               '(:foreground \"gold\" :weight 'bold))

  (esh-section esh-git
               \"ᛦ\"  ;  (git icon)
               (magit-get-current-branch)
               '(:foreground \"pink\"))

  ;; (esh-section esh-python
  ;;              \"\\xe928\"  ;  (python icon)
  ;;              pyvenv-virtual-env-name)

  (esh-section esh-clock
               \"\\xf017 \"  ;  (clock icon)
               (format-time-string \"%H:%M\" (current-time))
               '(:foreground \"forest green\"))

  ;; Below I implement a \"prompt number\" section
  (setq esh-prompt-num 0)
  (add-hook 'eshell-exit-hook (lambda () (setq esh-prompt-num 0)))
  (advice-add 'eshell-send-input :before
              (lambda (&rest args) (setq esh-prompt-num (incf esh-prompt-num))))

  (esh-section esh-num
               \"\\xf0c9 \"  ;  (list icon)
               (number-to-string esh-prompt-num)
               '(:foreground \"brown\"))

  ;; Choose which eshell-funcs to enable
  (setq eshell-funcs (list esh-dir esh-git esh-clock esh-num))

  ;; Enable the new eshell prompt
  (setq eshell-prompt-function 'esh-prompt-func)
#+END_SRC
* My own Eshell prompt

Entirely taken from [[http://www.modernemacs.com/post/custom-eshell/][Making eshell your own | Modern Emacs]]
#+BEGIN_SRC emacs-lisp
  (require 'dash)
  (require 's)

  (defmacro with-face (STR &rest PROPS)
    \"Return STR propertized with PROPS.\"
    `(propertize ,STR 'face (list ,@PROPS)))

  (defmacro esh-section (NAME ICON FORM &rest PROPS)
    \"Build eshell section NAME with ICON prepended to evaled FORM with PROPS.\"
    `(setq ,NAME
           (lambda () (when ,FORM
                        (-> ,ICON
                            (concat esh-section-delim ,FORM)
                            (with-face ,@PROPS))))))

  (defun esh-acc (acc x)
    \"Accumulator for evaluating and concatenating esh-sections.\"
    (--if-let (funcall x)
        (if (s-blank? acc)
            it
          (concat acc esh-sep it))
      acc))

  (defun esh-prompt-func ()
    \"Build `eshell-prompt-function'\"
    (concat esh-header
            (-reduce-from 'esh-acc \"\" eshell-funcs)
            \"\\n\"
            eshell-prompt-string))

  ;; Separator between esh-sections
  (setq esh-sep \" | \")  ; or \" | \"

  ;; Separator between an esh-section icon and form
  (setq esh-section-delim \" \")

  ;; Eshell prompt header
  (setq esh-header \"\\n┌─\")  ; or \"\\n┌─\"

  ;; Eshell prompt regexp and string. Unless you are varying the prompt by eg.
  ;; your login, these can be the same.
  (setq eshell-prompt-regexp \"└─> λ \")   ; or \"└─> \"
  (setq eshell-prompt-string \"└─> λ \")   ; or \"└─> \"

  (esh-section esh-dir
               \" \\xf07c \"  ;  (faicon folder)
               (abbreviate-file-name (eshell/pwd))
               '(:foreground \"gold\" :weight bold))

  (esh-section esh-git
               \"ᛦ\"  ;  (git icon)
               (magit-get-current-branch)
               '(:foreground \"pink\"))

  ;; (esh-section esh-python
  ;;              \"\\xe928\"  ;  (python icon)
  ;;              pyvenv-virtual-env-name)

  (esh-section esh-clock
               \"\\xf017 \"  ;  (clock icon)
               (format-time-string \"%H:%M\" (current-time))
               '(:foreground \"forest green\"))

  ;; Below I implement a \"prompt number\" section
  (setq esh-prompt-num 0)
  (add-hook 'eshell-exit-hook (lambda () (setq esh-prompt-num 0)))
  (advice-add 'eshell-send-input :before
              (lambda (&rest args) (setq esh-prompt-num (incf esh-prompt-num))))

  (esh-section esh-num
               \"\\xf0c9 \"  ;  (list icon)
               (number-to-string esh-prompt-num)
               '(:foreground \"brown\"))

  ;; Choose which eshell-funcs to enable
  (setq eshell-funcs (list esh-dir esh-git esh-clock esh-num))

  ;; Enable the new eshell prompt
  (setq eshell-prompt-function 'esh-prompt-func)
#+END_SRC
* Smartparens

Autopairing parentheses
#+BEGIN_SRC emacs-lisp
  (use-package smartparens
    :hook (eshell-mode . smartparens-mode)
    )
#+END_SRC
* Eshell-up

Go up directories easily
#+BEGIN_SRC emacs-lisp
  (use-package eshell-up)
#+END_SRC
* Eshell-z

Better and quicker usage of cd
#+BEGIN_SRC emacs-lisp
  (use-package eshell-z)
#+END_SRC
* Eshell-toggle

Toggle eshell window in bottom of current buffer
#+BEGIN_SRC emacs-lisp
  (use-package eshell-toggle
    :custom
    (eshell-toggle-size-fraction 3) ; How big is the window?
    ;; (eshell-toggle-use-projectile-root t)
    (eshell-toggle-use-git-root t)
    (eshell-toggle-init-function #'eshell-toggle-init-eshell) ; Terminal emulator to use
    (eshell-toggle-run-command nil) ; Command to run in new buffer
    :config

    (kb/leader-keys
      \"oe\" '(eshell-toggle :which-key \"Toggle Eshell\")
      )
    )
#+END_SRC
* Eshell-help

See help doctrings for functions easlily via =M-x esh-help-run-help=
#+BEGIN_SRC emacs-lisp
  (use-package esh-help
    :config
    (setup-esh-help-eldoc)
    )
#+END_SRC
* Shrink-path

Truncate eshell directory path
- Only exmaple configuration exists in Emacs (so far)
#+BEGIN_SRC emacs-lisp
  (use-package shrink-path)
#+END_SRC
* Esh-autosuggest

#+BEGIN_SRC emacs-lisp
  (use-package esh-autosuggest
    :disabled ; Fish does this better?
    :hook (eshell-mode . esh-autosuggest-mode)
    :custom
    (esh-autosuggest-delay 0.5)
    :config
    (set-face-foreground 'company-preview-common \"#4b5668\")
    (set-face-background 'company-preview nil)
    )
#+END_SRC
* Fish-completion

Uses pcomplete completion framework with completion from fish (the shell)
#+BEGIN_SRC emacs-lisp
  (use-package fish-completion
    :hook (eshell-mode . fish-completion-mode)
    :config
    (when (and (executable-find \"fish\")
               (require 'fish-completion nil t))
      (global-fish-completion-mode))
    )
#+END_SRC
* Eshell-syntax-highlighting

Zsh-esque syntax highlighting in eshell
#+BEGIN_SRC emacs-lisp
  (use-package eshell-syntax-highlighting
    :config
    (eshell-syntax-highlighting-global-mode t)
    )
#+END_SRC
* Vterm

#+begin_src emacs-lisp

#+end_src
" . 1) 9041 (t 24473 31982 321928 422000)) (emacs-undo-equiv-table (-1 . -3) (-15 . -17) (-4 . -6)))