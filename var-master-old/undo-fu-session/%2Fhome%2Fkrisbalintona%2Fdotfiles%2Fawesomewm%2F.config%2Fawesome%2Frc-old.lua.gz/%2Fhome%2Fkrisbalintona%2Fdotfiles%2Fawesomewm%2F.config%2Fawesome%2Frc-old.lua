((buffer-size . 22356) (buffer-checksum . "686eff0389724f36619663605f243cd0ba7df48d"))
((emacs-buffer-undo-list nil (apply 3 2420 2450 undo--wrap-and-run-primitive-undo 2420 2450 (("-- " . -2422) 2452)) (t 24518 53919 675489 976000)) (emacs-pending-undo-list (nil help-echo nil 72 . 1526) (nil fontified nil 72 . 1526) (nil font-lock-fontified t 72 . 1526) (nil line-prefix "  " 72 . 1526) (nil wrap-prefix "  " 72 . 1526) (nil font-lock-multiline t 72 . 1526) (nil face org-block-begin-line 72 . 1526) (72 . 1526) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3))) ; Scroll-margin
           (eshell-mode . (lambda () ; Change default face size
                            (face-remap-add-relative 'default :height 127) 
                            ))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    :config

              (kb/leader-keys
                \"oE\" '(eshell :which-key \"Open eshell\")
                )

              (general-define-key
               :keymaps 'eshell-mode-map
               [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
               [remap eshell-previous-matching-input] 'eshell-bol ; Jump after the prompt
               \"<home>\" 'eshell-bol
               )
              )
" . 72) 1237 nil ("    (add-hook 'eshell-mode-hook
" . 1206) 1222 (t 24476 39506 404523 659000) nil (nil rear-nonsticky nil 616 . 617) (nil fontified nil 591 . 617) (nil line-prefix "  " 591 . 617) (nil wrap-prefix "             " 591 . 617) (nil fontified t 591 . 617) (nil font-lock-fontified t 591 . 617) (nil help-echo nil 591 . 617) (nil src-block t 591 . 617) (nil font-lock-multiline t 591 . 617) (nil face (org-block) 591 . 617) (591 . 617) nil (590 . 591) nil ("; Change default face size" . 666) nil (537 . 553) nil (nil help-echo nil 72 . 1641) (nil fontified nil 72 . 1641) (nil font-lock-fontified t 72 . 1641) (nil line-prefix "  " 72 . 1641) (nil wrap-prefix "  " 72 . 1641) (nil font-lock-multiline t 72 . 1641) (nil face org-block-begin-line 72 . 1641) (72 . 1641) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
           (eshell-mode . (lambda ()
                           (face-remap-add-relative 'default :height 127) ; Change default face size
                           ))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    :config
    (add-hook 'eshell-mode-hook

              (kb/leader-keys
                \"oE\" '(eshell :which-key \"Open eshell\")
                )

              (general-define-key
               :keymaps 'eshell-mode-map
               [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
               [remap eshell-previous-matching-input] 'eshell-bol ; Jump after the prompt
               \"<home>\" 'eshell-bol
               )
              )
" . 72) 538 nil (563 . 564) (t 24476 39470 268281 506000) nil (nil help-echo nil 72 . 1638) (nil fontified nil 72 . 1638) (nil font-lock-fontified t 72 . 1638) (nil line-prefix "  " 72 . 1638) (nil wrap-prefix "  " 72 . 1638) (nil font-lock-multiline t 72 . 1638) (nil face org-block-begin-line 72 . 1638) (72 . 1638) ("  (use-package esh-mode
    :straight nil
    :hook ((eshell-mode . (lambda () ; UI enhancements
                            (visual-line-mode +1)
                            (set-display-table-slot standard-display-table 0 ?\\ )))
           (eshell-mode . (lambda () ; Text-wrap
                            (set-window-fringes nil 0 0)
                            (set-window-margins nil 1 nil)))
           (eshell-mode . (lambda () (setq-local scroll-margin 3)))
              (eshell-mode .(lambda ()
                (face-remap-add-relative 'default :height 127) ; Change default face size
                ))
           )
    :custom
    (eshell-kill-processes-on-exit t)
    (eshell-hist-ignoredups t)
    (eshell-scroll-to-bottom-on-input 'all)
    (eshell-scroll-to-bottom-on-output 'all)
    (eshell-input-filter (lambda (input) (not (string-match-p \"\\\\`\\\\s-+\" input)))) ; Don't record command in history if prefixed with whitespace
    (eshell-glob-case-insensitive t)
    (eshell-error-if-no-glob t)
    (eshell-banner-message \"Welcome to the shell, Onii-chan~ (◠﹏◠✿)\\n\")
    :config
    (add-hook 'eshell-mode-hook

    (kb/leader-keys
      \"oE\" '(eshell :which-key \"Open eshell\")
      )

    (general-define-key
     :keymaps 'eshell-mode-map
     [remap evil-first-non-blank] 'eshell-bol ; Jump after the prompt
     [remap eshell-previous-matching-input] 'eshell-bol ; Jump after the prompt
     \"<home>\" 'eshell-bol
     )
    )
" . 72) 577 (t 24476 39462 208376 175000)) (emacs-undo-equiv-table))