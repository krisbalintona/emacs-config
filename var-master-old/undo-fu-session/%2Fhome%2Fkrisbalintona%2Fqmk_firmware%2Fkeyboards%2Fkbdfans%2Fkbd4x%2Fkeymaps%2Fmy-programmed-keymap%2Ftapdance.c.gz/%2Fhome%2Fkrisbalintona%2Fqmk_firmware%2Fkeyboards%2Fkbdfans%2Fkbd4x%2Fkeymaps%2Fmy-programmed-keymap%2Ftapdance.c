((buffer-size . 9269) (buffer-checksum . "5d3f02505d94596489eef652624eec6fed605540"))
((emacs-buffer-undo-list nil ("  TD_F2,
" . 8463) ((marker . 8463) . -8) nil ("  [TD_F2] = ACTION_TAP_DANCE_FN_ADVANCED_TIME(NULL, f2_finished, f2_reset, 160),
" . 9276) ((marker . 9267) . -5) ((marker . 9267) . -80) ((marker* . 9267) . 14) ((marker . 9267) . -5) ((marker* . 9267) . 73) ((marker . 9267) . -5) ((marker . 9267) . -5) ((marker . 9267) . -8) ((marker . 8463) . -67) ((marker . 9266) . -80) 9343 nil (9341 . 9343) ("spc" . 9341) nil (9328 . 9330) ("F" . -9328) ((marker . 8463) . -1) ("2" . -9329) ((marker . 8463) . -1) 9330 (9328 . 9330) ("spc" . 9328) (t 24535 23550 741591 11000) nil (9328 . 9331) ("2" . 9328) ((marker . 8463) . -1) ("
                                              " . 9329) ((marker . 8463) . -47) ("f2" . 9376) ((marker . 8463) . -2) nil (9376 . 9378) (9329 . 9376) (9328 . 9329) ("spc" . 9328) (t 24535 23550 741591 11000) nil (9282 . 9284) (9281 . 9282) ("_SPC_CTL" . 9281) ((marker . 9267) . -7) ((marker . 9267) . -7) ((marker . 8463) . -7) ((marker) . -7) 9288 nil ("  [TD_F2] = ACTION_TAP_DANCE_FN_ADVANCED(NULL, dfl_finished, NULL),
" . 9276) ((marker . 9267) . -67) ((marker . 9267) . -68) ((marker . 9267) . -67) ((marker . 9267) . -67) ((marker . 9267) . -47) ((marker* . 9267) . 18) ((marker . 9267) . -47) ((marker . 9267) . -49) ((marker . 8463) . -5) 9281 nil (nil rear-nonsticky nil 9345 . 9346) ("
" . -9431) (9343 . 9432) 9325 nil (8470 . 8471) (" " . -8470) ((marker . 8463) . -1) ("i" . -8471) ((marker . 8463) . -1) 8472 (8470 . 8472) (" " . -8470) ((marker . 8463) . -1) 8471 (8469 . 8471) ("1" . -8469) ((marker . 9267) . -1) ((marker . 9267) . -1) ((marker . 8463) . -1) ("2" . -8470) ((marker . 8463) . -1) 8471 (8470 . 8471) ("," . 8470) ((marker . 9267) . -1) ((marker . 9267) . -1) (8468 . 8470) ("DFL" . 8468) nil (nil rear-nonsticky nil 8464 . 8465) ("
" . -8472) (8462 . 8473) 8453 nil (7227 . 7228) (7226 . 7227) (7225 . 7226) ("*" . -7225) ((marker . 8463) . -1) 7226 (7225 . 7226) nil (7203 . 7204) (7202 . 7203) nil (7200 . 7201) ("/" . 7200) (t 24535 23444 612642 389000) nil (2628 . 2629) (2627 . 2628) (2626 . 2627) nil (2618 . 2619) (2617 . 2618) (2616 . 2617) ("/" . 2616) (t 24535 21552 310418 219000) nil (62 . 63) 58 nil (nil rear-nonsticky nil 19 . 20) ("
" . -62) (19 . 63) 1 nil ("/**
 * Tap Dance config and functions
 **/
" . 1) ((marker . 9267) . -43) ((marker . 9267) . -42) nil (1 . 44) nil ("/**
 * Tap Dance config and functions
 **/
" . 1) ((marker . 9267) . -38) ((marker*) . 26) ((marker) . -23) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 9267) . -38) ((marker) . -43) ((marker . 1) . -38) ((marker . 1) . -38) ((marker) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -4) ((marker . 1) . -38) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) (t 24535 21475 754338 67000) nil (44 . 718) nil ("/* * Definitins */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

enum {
SINGLE_TAP = 1,
SINGLE_HOLD,
DOUBLE_TAP,
DOUBLE_SINGLE_TAP,
UNKNOWN_TAPS,
};

typedef struct {
  bool is_press_action;
  int state;
} tap;

// Getting state of key for use with tap dance
int cur_dance (qk_tap_dance_state_t *state) {
  if (state->count == 1) {
    if (state->interrupted || !state->pressed) {
      return SINGLE_TAP;
    } else {
      return SINGLE_HOLD;
    }
  }
  if (state->count == 2) {
    if (state->interrupted) {
      return DOUBLE_SINGLE_TAP;
    } else if (!state->pressed) {
      return DOUBLE_TAP;
    }
  }
  return UNKNOWN_TAPS;
}

" . 1) ((marker . 9267) . -674) ((marker . 9267) . -673) ((marker . 64) . -19) ((marker . 84) . -39) ((marker . 1) . -202) ((marker . 1) . -238) ((marker . 1) . -340) ((marker . 1) . -670) ((marker . 1) . -367) ((marker . 1) . -485) ((marker . 1) . -416) ((marker . 1) . -440) ((marker . 1) . -454) ((marker . 1) . -479) ((marker . 1) . -517) ((marker . 1) . -643) ((marker . 1) . -547) ((marker . 1) . -578) ((marker . 1) . -613) ((marker . 1) . -637) nil (1 . 675) nil ("/* * Definitins */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

enum {
SINGLE_TAP = 1,
SINGLE_HOLD,
DOUBLE_TAP,
DOUBLE_SINGLE_TAP,
UNKNOWN_TAPS,
};

typedef struct {
  bool is_press_action;
  int state;
} tap;

// Getting state of key for use with tap dance
int cur_dance (qk_tap_dance_state_t *state) {
  if (state->count == 1) {
    if (state->interrupted || !state->pressed) {
      return SINGLE_TAP;
    } else {
      return SINGLE_HOLD;
    }
  }
  if (state->count == 2) {
    if (state->interrupted) {
      return DOUBLE_SINGLE_TAP;
    } else if (!state->pressed) {
      return DOUBLE_TAP;
    }
  }
  return UNKNOWN_TAPS;
}

" . 44) ((marker* . 9267) . 656) ((marker . 64) . -19) ((marker . 84) . -39) ((marker . 247) . -202) ((marker . 283) . -238) ((marker . 385) . -340) ((marker . 715) . -670) ((marker . 412) . -367) ((marker . 530) . -485) ((marker . 461) . -416) ((marker . 485) . -440) ((marker . 499) . -454) ((marker . 524) . -479) ((marker . 562) . -517) ((marker . 688) . -643) ((marker . 592) . -547) ((marker . 623) . -578) ((marker . 658) . -613) ((marker . 682) . -637) ((marker . 719) . -674) ((marker . 719) . -674) ((marker . 9267) . -674) (t 24535 21475 754338 67000) nil (61 . 62) (60 . 61) (49 . 60) (44 . 49) (43 . 44) 41 nil (3 . 4) nil ("*" . 3) nil (709 . 710) (708 . 709) (707 . 708) nil (702 . 703) (701 . 702) nil (700 . 701) ("/" . 700) nil (1627 . 1628) (1626 . 1627) (1625 . 1626) nil (1617 . 1618) (1616 . 1617) nil (1615 . 1616) ("/" . 1615) nil (8455 . 8456) (8454 . 8455) (8453 . 8454) nil (8294 . 8295) (8293 . 8294) (8292 . 8293) nil (6286 . 6287) (6285 . 6286) (6284 . 6285) nil (5382 . 5383) (5381 . 5382) (5380 . 5381) nil ("/* * Testing */
" . 3541) ((marker) . -5) ((marker) . -15) ((marker . 3576) . -5) 3556 nil (3572 . 3573) (3571 . 3572) (3570 . 3571) nil (3558 . 3559) ("/" . 3558) nil (3546 . 3553) nil ("t" . -3549) ((marker) . -1) ("e" . -3550) ((marker) . -1) 3551 (3549 . 3551) nil (3541 . 3549) (t 24535 21385 778324 171000) nil ("*" . -3545) ((marker* . 9267) . 1) ((marker) . -1) 3546 nil (3544 . 3545) nil (" " . 3545) ((marker* . 9267) . 1) nil (3544 . 3545) nil (3543 . 3544) ("*" . 3543) nil ("*" . -3555) ((marker) . -1) ("/" . -3556) ((marker) . -1) 3557 (3556 . 3557) (3555 . 3556) (t 24535 21348 988578 100000) nil (3545 . 3546) (3544 . 3545) (3543 . 3544) (" " . -3543) 3544 (3543 . 3544) ("/" . 3543) nil (5366 . 5367) (5365 . 5366) (5364 . 5365) (" " . -5364) ((marker . 5403) . -1) ((marker) . -1) ((marker . 5403) . -1) 5365 (5364 . 5365) ("/" . 5364) (t 24535 21324 498742 526000) nil (6255 . 6256) (6254 . 6255) (6253 . 6254) (" " . -6253) ((marker) . -1) 6254 (6253 . 6254) ("/" . 6253) (t 24535 21307 915518 337000) nil (8261 . 8262) (8260 . 8261) nil (8259 . 8260) ("/" . 8259) nil (8409 . 8410) ("/" . 8409) (t 24535 21223 746042 583000) nil (8409 . 8410) ("?" . 8409) (8409 . 8410) ("*" . 8409) nil (8409 . 8410) nil ("/" . -8409) ((marker) . -1) 8410 (t 24535 21198 869520 541000) nil (" " . -8413) ((marker) . -1) 8414 (8412 . 8414) nil (8411 . 8412) (t 24535 21191 36231 697000) nil (9210 . 9211) ("1" . 9210) nil (9209 . 9211) ("~" . -9209) ((marker) . -1) 9210 (9209 . 9210) ("1" . -9209) ((marker) . -1) 9210 (9209 . 9210) ("DFL" . 9209) nil (nil rear-nonsticky nil 9204 . 9205) ("
" . -9271) (9202 . 9272) (t 24527 35888 911272 304000) nil ("sudo timeshift --create --comment \"After submitting my final\"" . 9202) ((marker) . -61) ((marker . 9267) . -61) ((marker . 9267) . -60) (nil rear-nonsticky t 9262 . 9263) nil (nil rear-nonsticky nil 9262 . 9263) (nil fontified nil 9202 . 9263) (9202 . 9263) (t 24527 35888 911272 304000) nil (9129 . 9130) ("7" . 9129) (t 24516 39805 970214 680000) nil (8732 . 8734) ("20" . 8732) (t 24515 16762 649282 16000) nil (8732 . 8734) ("13" . 8732) 8733 (t 24514 12349 517452 86000) nil (8648 . 8649) ("9" . 8648) nil (";" . 8736) nil (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (":" . -8736) (";" . -8737) (";" . -8738) 8739 (8737 . 8739) (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (t 24514 12310 301273 173000) nil (8733 . 8734) ("0" . 8733) (t 24513 48315 174093 828000) nil (8732 . 8734) ("07" . 8732) (t 24513 44147 223663 38000) nil (8732 . 8734) (">" . -8732) 8733 (8732 . 8733) ("00" . 8732) (t 24513 42827 688777 431000) nil (8732 . 8734) ("14" . 8732) (t 24480 13172 7173 876000) nil (8648 . 8649) ("7" . 8648) (8648 . 8649) ("3" . 8648) nil (8732 . 8734) ("09" . 8732) (t 24479 24507 400702 299000) nil (8732 . 8734) ("17" . 8732) nil (8647 . 8649) ("30" . 8647) nil (8732 . 8733) ("2" . 8732) (t 24479 23572 281530 571000) nil (8732 . 8733) ("3" . 8732) (t 24467 2102 670237 582000) nil (9129 . 9130) ("4" . 9129) nil (9129 . 9131) ("20" . 9129) (t 24467 2041 121648 380000) nil (9129 . 9131) ("55" . 9129) (t 24465 60486 351133 799000) nil (9129 . 9131) ("70" . 9129) (t 24465 60148 580180 309000) nil (8648 . 8649) ("7" . 8648) (t 24455 14937 187759 183000)) (emacs-pending-undo-list (9282 . 9284) (9281 . 9282) ("_SPC_CTL" . 9281) ((marker . 9267) . -7) ((marker . 9267) . -7) ((marker . 8463) . -7) ((marker) . -7) 9288 nil ("  [TD_F2] = ACTION_TAP_DANCE_FN_ADVANCED(NULL, dfl_finished, NULL),
" . 9276) ((marker . 9267) . -67) ((marker . 9267) . -68) ((marker . 9267) . -67) ((marker . 9267) . -67) ((marker . 9267) . -47) ((marker* . 9267) . 18) ((marker . 9267) . -47) ((marker . 9267) . -49) ((marker . 8463) . -5) 9281 nil (nil rear-nonsticky nil 9345 . 9346) ("
" . -9431) (9343 . 9432) 9325 nil (8470 . 8471) (" " . -8470) ((marker . 8463) . -1) ("i" . -8471) ((marker . 8463) . -1) 8472 (8470 . 8472) (" " . -8470) ((marker . 8463) . -1) 8471 (8469 . 8471) ("1" . -8469) ((marker . 9267) . -1) ((marker . 9267) . -1) ((marker . 8463) . -1) ("2" . -8470) ((marker . 8463) . -1) 8471 (8470 . 8471) ("," . 8470) ((marker . 9267) . -1) ((marker . 9267) . -1) (8468 . 8470) ("DFL" . 8468) nil (nil rear-nonsticky nil 8464 . 8465) ("
" . -8472) (8462 . 8473) 8453 nil (7227 . 7228) (7226 . 7227) (7225 . 7226) ("*" . -7225) ((marker . 8463) . -1) 7226 (7225 . 7226) nil (7203 . 7204) (7202 . 7203) nil (7200 . 7201) ("/" . 7200) (t 24535 23444 612642 389000) nil (2628 . 2629) (2627 . 2628) (2626 . 2627) nil (2618 . 2619) (2617 . 2618) (2616 . 2617) ("/" . 2616) (t 24535 21552 310418 219000) nil (62 . 63) 58 nil (nil rear-nonsticky nil 19 . 20) ("
" . -62) (19 . 63) 1 nil ("/**
 * Tap Dance config and functions
 **/
" . 1) ((marker . 9267) . -43) ((marker . 9267) . -42) nil (1 . 44) nil ("/**
 * Tap Dance config and functions
 **/
" . 1) ((marker . 9267) . -38) ((marker*) . 26) ((marker) . -23) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -43) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 9267) . -38) ((marker) . -43) ((marker . 1) . -38) ((marker . 1) . -38) ((marker) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -38) ((marker . 1) . -4) ((marker . 1) . -38) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) (t 24535 21475 754338 67000) nil (44 . 718) nil ("/* * Definitins */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

enum {
SINGLE_TAP = 1,
SINGLE_HOLD,
DOUBLE_TAP,
DOUBLE_SINGLE_TAP,
UNKNOWN_TAPS,
};

typedef struct {
  bool is_press_action;
  int state;
} tap;

// Getting state of key for use with tap dance
int cur_dance (qk_tap_dance_state_t *state) {
  if (state->count == 1) {
    if (state->interrupted || !state->pressed) {
      return SINGLE_TAP;
    } else {
      return SINGLE_HOLD;
    }
  }
  if (state->count == 2) {
    if (state->interrupted) {
      return DOUBLE_SINGLE_TAP;
    } else if (!state->pressed) {
      return DOUBLE_TAP;
    }
  }
  return UNKNOWN_TAPS;
}

" . 1) ((marker . 9267) . -674) ((marker . 9267) . -673) ((marker . 64) . -19) ((marker . 84) . -39) ((marker . 1) . -202) ((marker . 1) . -238) ((marker . 1) . -340) ((marker . 1) . -670) ((marker . 1) . -367) ((marker . 1) . -485) ((marker . 1) . -416) ((marker . 1) . -440) ((marker . 1) . -454) ((marker . 1) . -479) ((marker . 1) . -517) ((marker . 1) . -643) ((marker . 1) . -547) ((marker . 1) . -578) ((marker . 1) . -613) ((marker . 1) . -637) nil (1 . 675) nil ("/* * Definitins */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

enum {
SINGLE_TAP = 1,
SINGLE_HOLD,
DOUBLE_TAP,
DOUBLE_SINGLE_TAP,
UNKNOWN_TAPS,
};

typedef struct {
  bool is_press_action;
  int state;
} tap;

// Getting state of key for use with tap dance
int cur_dance (qk_tap_dance_state_t *state) {
  if (state->count == 1) {
    if (state->interrupted || !state->pressed) {
      return SINGLE_TAP;
    } else {
      return SINGLE_HOLD;
    }
  }
  if (state->count == 2) {
    if (state->interrupted) {
      return DOUBLE_SINGLE_TAP;
    } else if (!state->pressed) {
      return DOUBLE_TAP;
    }
  }
  return UNKNOWN_TAPS;
}

" . 44) ((marker* . 9267) . 656) ((marker . 64) . -19) ((marker . 84) . -39) ((marker . 247) . -202) ((marker . 283) . -238) ((marker . 385) . -340) ((marker . 715) . -670) ((marker . 412) . -367) ((marker . 530) . -485) ((marker . 461) . -416) ((marker . 485) . -440) ((marker . 499) . -454) ((marker . 524) . -479) ((marker . 562) . -517) ((marker . 688) . -643) ((marker . 592) . -547) ((marker . 623) . -578) ((marker . 658) . -613) ((marker . 682) . -637) ((marker . 719) . -674) ((marker . 719) . -674) ((marker . 9267) . -674) (t 24535 21475 754338 67000) nil (61 . 62) (60 . 61) (49 . 60) (44 . 49) (43 . 44) 41 nil (3 . 4) nil ("*" . 3) nil (709 . 710) (708 . 709) (707 . 708) nil (702 . 703) (701 . 702) nil (700 . 701) ("/" . 700) nil (1627 . 1628) (1626 . 1627) (1625 . 1626) nil (1617 . 1618) (1616 . 1617) nil (1615 . 1616) ("/" . 1615) nil (8455 . 8456) (8454 . 8455) (8453 . 8454) nil (8294 . 8295) (8293 . 8294) (8292 . 8293) nil (6286 . 6287) (6285 . 6286) (6284 . 6285) nil (5382 . 5383) (5381 . 5382) (5380 . 5381) nil ("/* * Testing */
" . 3541) ((marker) . -5) ((marker) . -15) ((marker . 3576) . -5) 3556 nil (3572 . 3573) (3571 . 3572) (3570 . 3571) nil (3558 . 3559) ("/" . 3558) nil (3546 . 3553) nil ("t" . -3549) ((marker) . -1) ("e" . -3550) ((marker) . -1) 3551 (3549 . 3551) nil (3541 . 3549) (t 24535 21385 778324 171000) nil ("*" . -3545) ((marker* . 9267) . 1) ((marker) . -1) 3546 nil (3544 . 3545) nil (" " . 3545) ((marker* . 9267) . 1) nil (3544 . 3545) nil (3543 . 3544) ("*" . 3543) nil ("*" . -3555) ((marker) . -1) ("/" . -3556) ((marker) . -1) 3557 (3556 . 3557) (3555 . 3556) (t 24535 21348 988578 100000) nil (3545 . 3546) (3544 . 3545) (3543 . 3544) (" " . -3543) 3544 (3543 . 3544) ("/" . 3543) nil (5366 . 5367) (5365 . 5366) (5364 . 5365) (" " . -5364) ((marker . 5403) . -1) ((marker) . -1) ((marker . 5403) . -1) 5365 (5364 . 5365) ("/" . 5364) (t 24535 21324 498742 526000) nil (6255 . 6256) (6254 . 6255) (6253 . 6254) (" " . -6253) ((marker) . -1) 6254 (6253 . 6254) ("/" . 6253) (t 24535 21307 915518 337000) nil (8261 . 8262) (8260 . 8261) nil (8259 . 8260) ("/" . 8259) nil (8409 . 8410) ("/" . 8409) (t 24535 21223 746042 583000) nil (8409 . 8410) ("?" . 8409) (8409 . 8410) ("*" . 8409) nil (8409 . 8410) nil ("/" . -8409) ((marker) . -1) 8410 (t 24535 21198 869520 541000) nil (" " . -8413) ((marker) . -1) 8414 (8412 . 8414) nil (8411 . 8412) (t 24535 21191 36231 697000) nil (9210 . 9211) ("1" . 9210) nil (9209 . 9211) ("~" . -9209) ((marker) . -1) 9210 (9209 . 9210) ("1" . -9209) ((marker) . -1) 9210 (9209 . 9210) ("DFL" . 9209) nil (nil rear-nonsticky nil 9204 . 9205) ("
" . -9271) (9202 . 9272) (t 24527 35888 911272 304000) nil ("sudo timeshift --create --comment \"After submitting my final\"" . 9202) ((marker) . -61) ((marker . 9267) . -61) ((marker . 9267) . -60) (nil rear-nonsticky t 9262 . 9263) nil (nil rear-nonsticky nil 9262 . 9263) (nil fontified nil 9202 . 9263) (9202 . 9263) (t 24527 35888 911272 304000) nil (9129 . 9130) ("7" . 9129) (t 24516 39805 970214 680000) nil (8732 . 8734) ("20" . 8732) (t 24515 16762 649282 16000) nil (8732 . 8734) ("13" . 8732) 8733 (t 24514 12349 517452 86000) nil (8648 . 8649) ("9" . 8648) nil (";" . 8736) nil (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (":" . -8736) (";" . -8737) (";" . -8738) 8739 (8737 . 8739) (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (":" . -8736) 8737 (8736 . 8737) (";" . -8736) 8737 (8736 . 8737) (t 24514 12310 301273 173000) nil (8733 . 8734) ("0" . 8733) (t 24513 48315 174093 828000) nil (8732 . 8734) ("07" . 8732) (t 24513 44147 223663 38000) nil (8732 . 8734) (">" . -8732) 8733 (8732 . 8733) ("00" . 8732) (t 24513 42827 688777 431000) nil (8732 . 8734) ("14" . 8732) (t 24480 13172 7173 876000) nil (8648 . 8649) ("7" . 8648) (8648 . 8649) ("3" . 8648) nil (8732 . 8734) ("09" . 8732) (t 24479 24507 400702 299000) nil (8732 . 8734) ("17" . 8732) nil (8647 . 8649) ("30" . 8647) nil (8732 . 8733) ("2" . 8732) (t 24479 23572 281530 571000) nil (8732 . 8733) ("3" . 8732) (t 24467 2102 670237 582000) nil (9129 . 9130) ("4" . 9129) nil (9129 . 9131) ("20" . 9129) (t 24467 2041 121648 380000) nil (9129 . 9131) ("55" . 9129) (t 24465 60486 351133 799000) nil (9129 . 9131) ("70" . 9129) (t 24465 60148 580180 309000) nil (8648 . 8649) ("7" . 8648) (t 24455 14937 187759 183000)) (emacs-undo-equiv-table (-16 . -20) (-13 . -15) (5 . -1) (-59 . -61) (-21 . -23) (-17 . -19)))