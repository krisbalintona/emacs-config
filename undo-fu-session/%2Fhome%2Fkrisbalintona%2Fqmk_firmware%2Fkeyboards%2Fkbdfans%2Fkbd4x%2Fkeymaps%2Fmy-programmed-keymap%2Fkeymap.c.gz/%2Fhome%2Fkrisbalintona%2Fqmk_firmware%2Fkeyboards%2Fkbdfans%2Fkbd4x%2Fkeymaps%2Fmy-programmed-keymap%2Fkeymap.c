((buffer-size . 4631) (buffer-checksum . "bab9ad7583f77a7254b3f8a2861440d24e041719"))
((emacs-buffer-undo-list nil (3011 . 3014) ("CTRL" . 3011) nil (2981 . 2985) ("GUI" . 2981) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -3) ((marker . 2981) . -2) ((marker . 2981) . -3) ((marker . 2981) . -2) ((marker . 2981) . -2) ((marker . 2981) . -2) ((marker . 2981) . -2) ((marker . 2981) . -2) ((marker . 2981) . -2) ((marker . 2981) . -2) ((marker . 2981) . -1) ((marker . 2981) . -2) ((marker . 2981) . -1) ((marker . 2981) . -1) ((marker . 2981) . -1) ((marker . 2981) . -1) ((marker . 2981) . -1) ((marker . 2981) . -1) ((marker . 2981) . -1) ((marker . 2981) . -1) (t 24453 7894 531888 34000)) (emacs-pending-undo-list (52705 . 52717) nil ("winner-mode)" . 52705) nil (52664 . 52675) nil ("use-package" . 52664) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) nil (52664 . 52675) nil ("use-package" . 52664) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) nil (52664 . 52675) nil ("use-package" . 52664) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) nil (52664 . 52675) nil ("use-package" . 52664) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) nil (52664 . 52675) ("ri" . 52664) ((marker . 3014) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker) . -1) ((marker . 52720) . -1) (52665 . 52666) ("e" . 52665) ((marker . 3014) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker) . -1) ((marker . 52720) . -1) nil (52665 . 52666) ("i" . -52665) ((marker . 3014) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker) . -1) ((marker . 52720) . -1) 52666 (52664 . 52666) ("use-package" . 52664) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -2) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) nil (52661 . 52724) ("(use-package winner-mode
:config
(winner-mode)
)
" . 52661) ((marker* . 52886) . 1) ((marker . 52886) . -47) ((marker . 52720) . -47) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 2457) . -24) ((marker*) . 49) ((marker) . -1) ((marker*) . 2) ((marker) . -48) ((marker) . -47) ((marker . 52720) . -47) nil (52708 . 52709) (52707 . 52708) (")" . -52707) ((marker . 3014) . -1) ((marker*) . 1) ((marker) . -1) 52708 (52700 . 52708) ("w" . -52700) ((marker . 3014) . -1) ("-" . -52701) ((marker . 3014) . -1) 52702 (52694 . 52702) (":" . -52694) ((marker . 3014) . -1) 52695 (52694 . 52695) (52693 . 52694) (52690 . 52693) ("f" . -52690) ((marker . 3014) . -1) ("i" . -52691) ((marker . 3014) . -1) ("g" . -52692) ((marker . 3014) . -1) 52693 (52686 . 52693) (52685 . 52686) (52679 . 52685) ("r" . -52679) ((marker . 3014) . -1) 52680 (52665 . 52680) (52662 . 52665) ("w" . -52662) ((marker . 2457) . -1) ((marker . 3014) . -1) ("i" . -52663) ((marker . 2457) . -1) ((marker . 3014) . -1) ("n" . -52664) ((marker . 2457) . -1) ((marker . 3014) . -1) ("n" . -52665) ((marker . 3014) . -1) 52666 (52662 . 52666) ("u" . -52662) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 52720) . -1) ((marker . 2457) . -1) ((marker . 3014) . -1) ("n" . -52663) ((marker . 3014) . -1) 52664 (52663 . 52664) (52661 . 52663) (t 24470 49063 865680 79000) nil (52638 . 52671) ("<el" . -52638) ((marker . 3014) . -3) 52641 (52638 . 52641) ("," . -52638) ((marker . 2457) . -1) ((marker . 3014) . -1) ("e" . -52639) ((marker . 2457) . -1) ((marker . 3014) . -1) 52640 (52638 . 52640) (52636 . 52638) (52625 . 52636) ("w" . -52625) ((marker . 3014) . -1) ("i" . -52626) ((marker . 3014) . -1) ("n" . -52627) ((marker . 3014) . -1) ("n" . -52628) ((marker . 3014) . -1) 52629 (52625 . 52629) (52622 . 52626) ("** 
" . 50878) ((marker . 50878) . -4) ((marker . 3014) . -3) 50881 (50878 . 50882) ("** 
" . 52622) ((marker . 52969) . -4) ((marker . 3014) . -3) 52625 nil (52621 . 52625) 50886 (t 24470 48411 97234 433000) nil (88238 . 91964) ("        (use-package org-roam
          :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
          :after company ; Necessary for some reason
          :custom
          (org-roam-directory kb/roam-dir)
          (org-roam-verbose nil) ; Don't echo messages that aren't errors
          (org-roam-completion-system 'ivy)
          (org-roam-completions-everywhere t)
          (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
          (org-roam-buffer-window-parameters '((no-other-window . t)
                                               (no-delete-other-windows . t)
                                               ))
          (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
          (org-roam-index-file \"index.org\") ; My Index
        (org-roam-tag-separator \" \")
      (org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)
    (org-roam-completion-everywhere t) ; Org-roam completion everywhere
          ;; Roam-buffer specific changes
    (org-roam-graph-extra-config '((\"rankdir\" . \"LR\"))) ; Extra options passed to graphviz
          (org-roam-buffer-prepare-hook
           '(org-roam-buffer--insert-title
             org-roam-buffer--insert-backlinks
             org-roam-buffer--insert-ref-links))
          (org-roam-buffer-width 0.20)
          :config
          (org-roam-mode)

          (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
          (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

          ;; Overall faces
          (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

          (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
          (add-hook 'org-roam-buffer-prepare-hook
                    (lambda ()
                      (face-remap-add-relative 'default :height 109)
                      (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                      (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                      (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                      (face-remap-add-relative 'org-level-1 :height 140)
                      (face-remap-add-relative 'org-level-2 :height 117)
                      (face-remap-add-relative 'org-level-3 :height 114)
                      ))

          (kb/leader-keys
            \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
            \"nf\" '(org-roam-find-file :which-key \"Find file\")
            \"ng\" '(org-roam-graph :which-key \"Show graph\")
            \"ni\" '(org-roam-insert :which-key \"Insert note\")
            \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
            ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
            \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
            \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
            \"nc\" '(org-roam-capture :which-key \"Roam capture\")

            \"nD\" '(:ignore t :which-key \"Call the doctor\")
            \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
            \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                      (interactive)
                      (let ((current-prefix-arg 4))
                        (call-interactively 'org-roam-doctor)
                        ))
                    :which-key \"Doctor all files\")

            ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
            ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
            ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
            ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
            ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
            )
          )
" . 88238) ((marker . 52886) . -1131) ((marker . 52720) . -1013) ((marker* . 52959) . 2898) ((marker . 52720) . -1131) ((marker . 52720) . -1017) ((marker) . -1017) ((marker*) . 3087) ((marker) . -1018) ((marker*) . 3054) ((marker) . -1051) ((marker) . -1017) ((marker) . -1131) ((marker) . -1131) 89251 nil (88238 . 92342) ("      (use-package org-roam
        :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
        :after company ; Necessary for some reason
        :custom
        (org-roam-directory kb/roam-dir)
        (org-roam-verbose nil) ; Don't echo messages that aren't errors
        (org-roam-completion-system 'ivy)
        (org-roam-completions-everywhere t)
        (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
        (org-roam-buffer-window-parameters '((no-other-window . t)
                                             (no-delete-other-windows . t)
                                             ))
        (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
        (org-roam-index-file \"index.org\") ; My Index
      (org-roam-tag-separator \" \")
    (org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)
  (org-roam-completion-everywhere t) ; Org-roam completion everywhere
        ;; Roam-buffer specific changes
(org-roam-graph-extra-config '((\"rankdir\" . \"LR\"))) ; Extra options passed to graphviz
        (org-roam-buffer-prepare-hook
         '(org-roam-buffer--insert-title
           org-roam-buffer--insert-backlinks
           org-roam-buffer--insert-ref-links))
        (org-roam-buffer-width 0.20)
        :config
        (org-roam-mode)

        (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
        (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

        ;; Overall faces
        (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

        (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
        (add-hook 'org-roam-buffer-prepare-hook
                  (lambda ()
                    (face-remap-add-relative 'default :height 109)
                    (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                    (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                    (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                    (face-remap-add-relative 'org-level-1 :height 140)
                    (face-remap-add-relative 'org-level-2 :height 117)
                    (face-remap-add-relative 'org-level-3 :height 114)
                    ))

        (kb/leader-keys
          \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
          \"nf\" '(org-roam-find-file :which-key \"Find file\")
          \"ng\" '(org-roam-graph :which-key \"Show graph\")
          \"ni\" '(org-roam-insert :which-key \"Insert note\")
          \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
          ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
          \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
          \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
          \"nc\" '(org-roam-capture :which-key \"Roam capture\")

          \"nD\" '(:ignore t :which-key \"Call the doctor\")
          \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
          \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                    (interactive)
                    (let ((current-prefix-arg 4))
                      (call-interactively 'org-roam-doctor)
                      ))
                  :which-key \"Doctor all files\")

          ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
          ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
          ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
          ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
          ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
          )
        )
" . 88238) ((marker* . 52886) . 2793) ((marker . 52886) . -1177) ((marker . 52720) . -1169) ((marker* . 52959) . 2792) ((marker . 52720) . -1177) ((marker . 52720) . -1177) ((marker . 52720) . -1120) ((marker . 52720) . -1140) ((marker) . -1177) ((marker) . -1119) ((marker) . -1177) ((marker) . -1177) 89415 nil (89401 . 89415) (89380 . 89401) (89379 . 89380) nil (nil rear-nonsticky nil 89378 . 89379) (nil fontified nil 89358 . 89379) (89358 . 89379) nil (89357 . 89358) (t 24470 48360 721206 491000) nil (nil rear-nonsticky nil 89356 . 89357) (nil fontified nil 89330 . 89357) (89330 . 89357) nil (89329 . 89330) (88238 . 92122) ("    (use-package org-roam
      :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
      :after company ; Necessary for some reason
      :custom
      (org-roam-directory kb/roam-dir)
      (org-roam-verbose nil) ; Don't echo messages that aren't errors
      (org-roam-completion-system 'ivy)
      (org-roam-completions-everywhere t)
      (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
      (org-roam-buffer-window-parameters '((no-other-window . t)
                                           (no-delete-other-windows . t)
                                           ))
      (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
      (org-roam-index-file \"index.org\") ; My Index
    (org-roam-tag-separator \" \")
  (org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)
(org-roam-completion-everywhere t) ; Org-roam completion everywhere
      ;; Roam-buffer specific changes

      (org-roam-buffer-prepare-hook
       '(org-roam-buffer--insert-title
         org-roam-buffer--insert-backlinks
         org-roam-buffer--insert-ref-links))
      (org-roam-buffer-width 0.20)
      :config
      (org-roam-mode)

      (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
      (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

      ;; Overall faces
      (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

      (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
      (add-hook 'org-roam-buffer-prepare-hook
                (lambda ()
                  (face-remap-add-relative 'default :height 109)
                  (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                  (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                  (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                  (face-remap-add-relative 'org-level-1 :height 140)
                  (face-remap-add-relative 'org-level-2 :height 117)
                  (face-remap-add-relative 'org-level-3 :height 114)
                  ))

      (kb/leader-keys
        \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
        \"nf\" '(org-roam-find-file :which-key \"Find file\")
        \"ng\" '(org-roam-graph :which-key \"Show graph\")
        \"ni\" '(org-roam-insert :which-key \"Insert note\")
        \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
        ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
        \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
        \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
        \"nc\" '(org-roam-capture :which-key \"Roam capture\")

        \"nD\" '(:ignore t :which-key \"Call the doctor\")
        \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
        \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                  (interactive)
                  (let ((current-prefix-arg 4))
                    (call-interactively 'org-roam-doctor)
                    ))
                :which-key \"Doctor all files\")

        ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
        ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
        ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
        ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
        ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
        )
      )
" . 88238) ((marker* . 52886) . 2738) ((marker . 52886) . -1054) ((marker . 88585) . -1054) ((marker) . -1054) ((marker) . -1054) 89293 (89292 . 89293) (t 24470 48189 150041 139000) 89292 nil (89243 . 89254) (89224 . 89243) ("R" . -89224) ((marker) . -1) ("o" . -89225) ((marker) . -1) ("a" . -89226) ((marker) . -1) ("m" . -89227) ((marker) . -1) (" " . -89228) ((marker) . -1) ("c" . -89229) ((marker) . -1) ("o" . -89230) ((marker) . -1) ("m" . -89231) ((marker) . -1) ("p" . -89232) ((marker) . -1) ("l" . -89233) ((marker) . -1) ("i" . -89234) ((marker) . -1) 89235 (89218 . 89235) (t 24470 48167 910308 595000) nil (89199 . 89218) (89196 . 89199) ("k" . -89196) ((marker) . -1) ("j" . -89197) ((marker) . -1) 89198 (89196 . 89198) (t 24470 48121 24231 483000) (89187 . 89196) (88238 . 91924) ("  (use-package org-roam
    :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
    :after company ; Necessary for some reason
    :custom
    (org-roam-directory kb/roam-dir)
    (org-roam-verbose nil) ; Don't echo messages that aren't errors
    (org-roam-completion-system 'ivy)
    (org-roam-completions-everywhere t)
    (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
    (org-roam-buffer-window-parameters '((no-other-window . t)
                                         (no-delete-other-windows . t)
                                         ))
    (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
    (org-roam-index-file \"index.org\") ; My Index
  (org-roam-tag-separator \" \")
(org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)

    ;; Roam-buffer specific changes
    (org-roam-buffer-prepare-hook
     '(org-roam-buffer--insert-title
       org-roam-buffer--insert-backlinks
       org-roam-buffer--insert-ref-links))
    (org-roam-buffer-width 0.20)
    :config
    (org-roam-mode)

    (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
    (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

    ;; Overall faces
    (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

    (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
    (add-hook 'org-roam-buffer-prepare-hook
              (lambda ()
                (face-remap-add-relative 'default :height 109)
                (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                (face-remap-add-relative 'org-level-1 :height 140)
                (face-remap-add-relative 'org-level-2 :height 117)
                (face-remap-add-relative 'org-level-3 :height 114)
                ))

    (kb/leader-keys
      \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
      \"nf\" '(org-roam-find-file :which-key \"Find file\")
      \"ng\" '(org-roam-graph :which-key \"Show graph\")
      \"ni\" '(org-roam-insert :which-key \"Insert note\")
      \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
      ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
      \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
      \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
      \"nc\" '(org-roam-capture :which-key \"Roam capture\")

      \"nD\" '(:ignore t :which-key \"Call the doctor\")
      \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
      \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                (interactive)
                (let ((current-prefix-arg 4))
                  (call-interactively 'org-roam-doctor)
                  ))
              :which-key \"Doctor all files\")

      ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
      ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
      ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
      ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
      ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
      )
    )
" . 88238) ((marker* . 52886) . 2641) ((marker . 52886) . -916) ((marker . 52720) . -809) ((marker . 52720) . -838) ((marker . 88585) . -807) ((marker . 88585) . -916) ((marker) . -878) ((marker) . -988) 89155 (89154 . 89155) 89116 nil ("
" . 89154) (88238 . 91796) ("    (use-package org-roam
      :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
      :after company ; Necessary for some reason
      :custom
      (org-roam-directory kb/roam-dir)
      (org-roam-verbose nil) ; Don't echo messages that aren't errors
      (org-roam-completion-system 'ivy)
      (org-roam-completions-everywhere t)
      (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
      (org-roam-buffer-window-parameters '((no-other-window . t)
                                           (no-delete-other-windows . t)
                                           ))
      (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
      (org-roam-index-file \"index.org\") ; My Index
    (org-roam-tag-separator \" \")
  (org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)

      ;; Roam-buffer specific changes
      (org-roam-buffer-prepare-hook
       '(org-roam-buffer--insert-title
         org-roam-buffer--insert-backlinks
         org-roam-buffer--insert-ref-links))
      (org-roam-buffer-width 0.20)
      :config
      (org-roam-mode)

      (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
      (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

      ;; Overall faces
      (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

      (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
      (add-hook 'org-roam-buffer-prepare-hook
                (lambda ()
                  (face-remap-add-relative 'default :height 109)
                  (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                  (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                  (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                  (face-remap-add-relative 'org-level-1 :height 140)
                  (face-remap-add-relative 'org-level-2 :height 117)
                  (face-remap-add-relative 'org-level-3 :height 114)
                  ))

      (kb/leader-keys
        \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
        \"nf\" '(org-roam-find-file :which-key \"Find file\")
        \"ng\" '(org-roam-graph :which-key \"Show graph\")
        \"ni\" '(org-roam-insert :which-key \"Insert note\")
        \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
        ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
        \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
        \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
        \"nc\" '(org-roam-capture :which-key \"Roam capture\")

        \"nD\" '(:ignore t :which-key \"Call the doctor\")
        \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
        \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                  (interactive)
                  (let ((current-prefix-arg 4))
                    (call-interactively 'org-roam-doctor)
                    ))
                :which-key \"Doctor all files\")

        ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
        ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
        ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
        ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
        ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
        )
      )
" . 88238) ((marker* . 52886) . 2737) ((marker) . -949) ((marker) . -949) nil (88238 . 91924) ("  (use-package org-roam
    :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
    :after company ; Necessary for some reason
    :custom
    (org-roam-directory kb/roam-dir)
    (org-roam-verbose nil) ; Don't echo messages that aren't errors
    (org-roam-completion-system 'ivy)
    (org-roam-completions-everywhere t)
    (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
    (org-roam-buffer-window-parameters '((no-other-window . t)
                                         (no-delete-other-windows . t)
                                         ))
    (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
    (org-roam-index-file \"index.org\") ; My Index
  (org-roam-tag-separator \" \")
(org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)

    ;; Roam-buffer specific changes
    (org-roam-buffer-prepare-hook
     '(org-roam-buffer--insert-title
       org-roam-buffer--insert-backlinks
       org-roam-buffer--insert-ref-links))
    (org-roam-buffer-width 0.20)
    :config
    (org-roam-mode)

    (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
    (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

    ;; Overall faces
    (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

    (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
    (add-hook 'org-roam-buffer-prepare-hook
              (lambda ()
                (face-remap-add-relative 'default :height 109)
                (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                (face-remap-add-relative 'org-level-1 :height 140)
                (face-remap-add-relative 'org-level-2 :height 117)
                (face-remap-add-relative 'org-level-3 :height 114)
                ))

    (kb/leader-keys
      \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
      \"nf\" '(org-roam-find-file :which-key \"Find file\")
      \"ng\" '(org-roam-graph :which-key \"Show graph\")
      \"ni\" '(org-roam-insert :which-key \"Insert note\")
      \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
      ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
      \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
      \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
      \"nc\" '(org-roam-capture :which-key \"Roam capture\")

      \"nD\" '(:ignore t :which-key \"Call the doctor\")
      \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
      \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                (interactive)
                (let ((current-prefix-arg 4))
                  (call-interactively 'org-roam-doctor)
                  ))
              :which-key \"Doctor all files\")

      ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
      ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
      ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
      ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
      ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
      )
    )
" . 88238) ((marker* . 52886) . 2641) ((marker . 52886) . -916) ((marker . 52720) . -809) ((marker . 52720) . -838) ((marker . 88585) . -807) ((marker . 88585) . -916) ((marker) . -808) ((marker) . -988) ((marker*) . 2750) ((marker) . -809) ((marker*) . 2707) ((marker) . -852) 89155 (89154 . 89155) 89046 nil ("
" . 89154) (88238 . 91796) ("    (use-package org-roam
      :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
      :after company ; Necessary for some reason
      :custom
      (org-roam-directory kb/roam-dir)
      (org-roam-verbose nil) ; Don't echo messages that aren't errors
      (org-roam-completion-system 'ivy)
      (org-roam-completions-everywhere t)
      (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
      (org-roam-buffer-window-parameters '((no-other-window . t)
                                           (no-delete-other-windows . t)
                                           ))
      (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
      (org-roam-index-file \"index.org\") ; My Index
    (org-roam-tag-separator \" \")
  (org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)

      ;; Roam-buffer specific changes
      (org-roam-buffer-prepare-hook
       '(org-roam-buffer--insert-title
         org-roam-buffer--insert-backlinks
         org-roam-buffer--insert-ref-links))
      (org-roam-buffer-width 0.20)
      :config
      (org-roam-mode)

      (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
      (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

      ;; Overall faces
      (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

      (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
      (add-hook 'org-roam-buffer-prepare-hook
                (lambda ()
                  (face-remap-add-relative 'default :height 109)
                  (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                  (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                  (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                  (face-remap-add-relative 'org-level-1 :height 140)
                  (face-remap-add-relative 'org-level-2 :height 117)
                  (face-remap-add-relative 'org-level-3 :height 114)
                  ))

      (kb/leader-keys
        \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
        \"nf\" '(org-roam-find-file :which-key \"Find file\")
        \"ng\" '(org-roam-graph :which-key \"Show graph\")
        \"ni\" '(org-roam-insert :which-key \"Insert note\")
        \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
        ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
        \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
        \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
        \"nc\" '(org-roam-capture :which-key \"Roam capture\")

        \"nD\" '(:ignore t :which-key \"Call the doctor\")
        \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
        \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                  (interactive)
                  (let ((current-prefix-arg 4))
                    (call-interactively 'org-roam-doctor)
                    ))
                :which-key \"Doctor all files\")

        ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
        ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
        ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
        ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
        ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
        )
      )
" . 88238) ((marker* . 52886) . 2737) ((marker) . -949) ((marker) . -949) nil (88238 . 91924) ("  (use-package org-roam
    :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
    :after company ; Necessary for some reason
    :custom
    (org-roam-directory kb/roam-dir)
    (org-roam-verbose nil) ; Don't echo messages that aren't errors
    (org-roam-completion-system 'ivy)
    (org-roam-completions-everywhere t)
    (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
    (org-roam-buffer-window-parameters '((no-other-window . t)
                                         (no-delete-other-windows . t)
                                         ))
    (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
    (org-roam-index-file \"index.org\") ; My Index
  (org-roam-tag-separator \" \")
(org-roam-link-use-custom-faces 'everywhere) ; Use org-roam-link face everywhere (including org-roam-buffer)

    ;; Roam-buffer specific changes
    (org-roam-buffer-prepare-hook
     '(org-roam-buffer--insert-title
       org-roam-buffer--insert-backlinks
       org-roam-buffer--insert-ref-links))
    (org-roam-buffer-width 0.20)
    :config
    (org-roam-mode)

    (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
    (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

    ;; Overall faces
    (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

    (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
    (add-hook 'org-roam-buffer-prepare-hook
              (lambda ()
                (face-remap-add-relative 'default :height 109)
                (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                (face-remap-add-relative 'org-level-1 :height 140)
                (face-remap-add-relative 'org-level-2 :height 117)
                (face-remap-add-relative 'org-level-3 :height 114)
                ))

    (kb/leader-keys
      \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
      \"nf\" '(org-roam-find-file :which-key \"Find file\")
      \"ng\" '(org-roam-graph :which-key \"Show graph\")
      \"ni\" '(org-roam-insert :which-key \"Insert note\")
      \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
      ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
      \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
      \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
      \"nc\" '(org-roam-capture :which-key \"Roam capture\")

      \"nD\" '(:ignore t :which-key \"Call the doctor\")
      \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
      \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                (interactive)
                (let ((current-prefix-arg 4))
                  (call-interactively 'org-roam-doctor)
                  ))
              :which-key \"Doctor all files\")

      ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
      ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
      ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
      ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
      ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
      )
    )
" . 88238) ((marker* . 52886) . 2641) ((marker . 52886) . -916) ((marker . 52720) . -809) ((marker . 52720) . -838) ((marker . 88585) . -807) ((marker . 88585) . -916) ((marker) . -808) ((marker) . -988) ((marker*) . 2750) ((marker) . -809) ((marker*) . 2707) ((marker) . -852) 89155 (89154 . 89155) 89046 nil ("
" . 89379) (t 24470 47932 769918 41000) nil (89134 . 89154) ("i" . -89134) ((marker) . -1) ("n" . -89135) ((marker) . -1) ("g" . -89136) ((marker) . -1) 89137 (89126 . 89137) (89120 . 89126) (89099 . 89120) ("-" . -89099) ((marker) . -1) 89100 (89093 . 89100) ("U" . -89093) ((marker) . -1) ("s" . -89094) ((marker) . -1) ("e" . -89095) ((marker) . -1) 89096 (89085 . 89096) (89078 . 89085) ("\"" . -89078) ((marker) . -1) 89079 (89077 . 89079) (t 24470 47887 397147 877000) nil (" " . -89077) ((marker) . -1) 89078 nil (89077 . 89078) (t 24470 47883 903857 828000) nil (nil rear-nonsticky nil 89076 . 89077) (nil fontified nil 89047 . 89077) (89047 . 89077) nil (89046 . 89047) nil (89045 . 89046) (t 24470 47816 501357 393000) 89045 nil ("org-roam-link-use-custom-faces" . 89045) ((marker . 52720) . -29) ((marker) . -30) (nil rear-nonsticky t 89074 . 89075) nil (nil rear-nonsticky nil 89074 . 89075) (nil fontified nil 89045 . 89075) (89045 . 89075) (t 24470 47816 501357 393000) nil (" " . -89045) ((marker) . -1) 89046 nil (89043 . 89046) (89040 . 89043) (89018 . 89040) ("o" . -89018) ((marker) . -1) ("r" . -89019) ((marker) . -1) 89020 (89018 . 89020) (t 24470 47801 678206 621000) ("r" . -89018) ((marker) . -1) ("o" . -89019) ((marker) . -1) ("a" . -89020) ((marker) . -1) 89021 (89017 . 89021) (88238 . 91659) ("  (use-package org-roam
    :quelpa (org-roam :fetcher github :repo \"org-roam/org-roam\")
    :after company ; Necessary for some reason
    :custom
    (org-roam-directory kb/roam-dir)
    (org-roam-verbose nil) ; Don't echo messages that aren't errors
    (org-roam-completion-system 'ivy)
    (org-roam-completions-everywhere t)
    (org-roam-link-auto-replace t) ; Replace roam link type with file link type when possible
    (org-roam-buffer-window-parameters '((no-other-window . t)
                                         (no-delete-other-windows . t)
                                         ))
    (org-roam-db-gc-threshold most-positive-fixnum) ; Temporarily increase GC threshold during intensive org-roam operations
    (org-roam-index-file \"index.org\") ; My Index

    ;; Roam-buffer specific changes
    (org-roam-buffer-prepare-hook
     '(org-roam-buffer--insert-title
       org-roam-buffer--insert-backlinks
       org-roam-buffer--insert-ref-links))
    (org-roam-buffer-width 0.20)

    :config
    (org-roam-mode)

    (add-to-list 'org-open-link-functions 'org-roam--open-fuzzy-link)
    (add-to-list 'org-open-at-point-functions 'org-roam-open-id-at-point)

    ;; Overall faces
    (set-face-attribute 'org-roam-link nil :inherit 'org-link :italic nil :foreground \"goldenrod3\")

    (add-hook 'org-roam-buffer-prepare-hook #'hide-mode-line-mode) ; Hide modeline in org-roam buffer
    (add-hook 'org-roam-buffer-prepare-hook
              (lambda ()
                (face-remap-add-relative 'default :height 109)
                (face-remap-add-relative 'org-document-title :height 145 :foreground \"DarkOrange3\")
                (face-remap-add-relative 'org-roam-link :height 112 :slant 'normal)
                (face-remap-add-relative 'org-link :inherit 'org-roam-link) ; For some reason this is being used instead of the proper org-roam-link face?
                (face-remap-add-relative 'org-level-1 :height 140)
                (face-remap-add-relative 'org-level-2 :height 117)
                (face-remap-add-relative 'org-level-3 :height 114)
                ))

    (kb/leader-keys
      \"nb\" '(org-roam-switch-to-buffer :which-key \"Switch to buffer\")
      \"nf\" '(org-roam-find-file :which-key \"Find file\")
      \"ng\" '(org-roam-graph :which-key \"Show graph\")
      \"ni\" '(org-roam-insert :which-key \"Insert note\")
      \"nI\" '(org-roam-jump-to-index :which-key \"Go to index\")
      ;; \"nI\" '(org-roam-insert-immediate :which-key \"Insert now\") ; Calls org-roam-capture-immediate-template
      \"nl\" '(org-roam :which-key \"Toggle Roam buffer\")
      \"nL\" '(org-roam-db-build-cache :which-key \"Rebuild cache\")
      \"nc\" '(org-roam-capture :which-key \"Roam capture\")

      \"nD\" '(:ignore t :which-key \"Call the doctor\")
      \"nDt\" '(org-roam-doctor :which-key \"Doctor this file\")
      \"nDa\" '((lambda () ; Call org-roam-doctor with universal argument (C-u)
                (interactive)
                (let ((current-prefix-arg 4))
                  (call-interactively 'org-roam-doctor)
                  ))
              :which-key \"Doctor all files\")

      ;; \"nd\" '(:ignore t :which-key \"Roam dailies\")
      ;; \"ndd\" '(org-roam-dailies-date :which-key \"Choose date\")
      ;; \"ndt\" '(org-roam-dailies-today :which-key \"Today\")
      ;; \"ndm\" '(org-roam-dailies-tomorrow :which-key \"Tomorrow\")
      ;; \"ndy\" '(org-roam-dailies-yesterday :which-key \"Yesterday\")
      )
    )
" . 88238) ((marker . 52886) . -778) ((marker . 52720) . -728) ((marker . 52720) . -776) ((marker . 88585) . -369) ((marker) . -1235) ((marker) . -732) ((marker*) . 2687) ((marker) . -733) ((marker*) . 2655) ((marker) . -765) 89015 (89014 . 89015) 88970 nil (nil rear-nonsticky nil 88969 . 88970) (88966 . 89015) nil ("    (org-roam-index-file \"index.org\") ; My Index
" . 89191) nil ("
" . 88966) (t 24470 47751 318825 53000) nil (43775 . 48579) ("  (use-package desktop
    :custom
    (desktop-save t) ; Always save when quitting Emacs or changing desktop
    (desktop-path `(,user-emacs-directory))
    (desktop-dirname user-emacs-directory)
    (desktop-base-file-name \"emacs-save-desktop\")
    (desktop-restore-eager t) ; Lazily restore buffers to reduce startup time
    (desktop-restore-eager 12) ; Lazily restore buffers to reduce startup time
    (desktop-lazy-verbose nil) ; Don't be verbose when lazy loading buffers
    (desktop-lazy-idle-delay 10) ; Wait 10 seconds until lazy loading buffers
    (desktop-auto-save-timeout 20) ; Idle time until save
    (desktop-restore-frames t) ; Restore frames too
    (desktop-load-locked-desktop t) ; Always load so that it is compatible with daemon
    ;; (desktop-restore-reuses-frames 'keep) ; Keep current frames when restoring session
    (history-length 1000) ; This is what Doom uses
    :config
    (desktop-save-mode)

    (setq desktop-buffers-not-to-save ;; Don't save these buffers
          (concat \"\\\\(\"
                  \"^nn\\\\.a[0-9]+\\\\|\\\\.log\\\\|(ftp)\\\\|^tags\\\\|^TAGS\"
                  \"\\\\|\\\\.emacs.*\\\\|\\\\.diary\\\\|\\\\.newsrc-dribble\\\\|\\\\.bbdb\"
                  \"\\\\)$\"))
    (add-to-list 'desktop-modes-not-to-save 'dired-mode)
    (add-to-list 'desktop-modes-not-to-save 'Info-mode)
    (add-to-list 'desktop-modes-not-to-save 'info-lookup-mode)
    (add-to-list 'desktop-modes-not-to-save 'fundamental-mode)

    ;; Remove desktop after it's been read
    (add-hook 'desktop-after-read-hook
              '(lambda ()
                 ;; desktop-remove clears desktop-dirname
                 (setq desktop-dirname-tmp desktop-dirname)
                 (desktop-remove)
                 (setq desktop-dirname desktop-dirname-tmp)
                 (org-mode-restart)
                 ))

    (defun saved-session ()
      (file-exists-p (concat desktop-dirname desktop-base-file-name)))

    ;; Use session-restore to restore the desktop manually
    (defun session-restore ()
      \"Restore a saved emacs session.\"
      (interactive)
      (if (saved-session)
          (desktop-read)
        (message \"No desktop found.\")))

    ;; Use session-save to save the desktop manually
    (defun kb/prompt-session-save ()
      \"Save an emacs session.\"
      (interactive)
      (if (saved-session)
          (if (y-or-n-p \"Overwrite existing desktop? \")
              (desktop-save-in-desktop-dir)
            (message \"Session not saved.\"))
        (desktop-save-in-desktop-dir)
        ))

    (defun kb/auto-session-save ()
      (interactive)
      ;; Don't call desktop-save-in-desktop-dir, as it prints a message.
      (if (eq (desktop-owner) (emacs-pid))
          (desktop-save-in-desktop-dir)))
    ;; (add-hook 'after-save-hook 'kb/auto-session-save) ; Save constantly
    (run-with-timer 0 480 'kb/auto-session-save) ; Save every 10 minutes

    ;; Restore when I want it to
    (add-hook 'after-init-hook
              '(lambda ()
                 (if (saved-session)
                     ;; (if (y-or-n-p \"Restore desktop? \")    )
                     (session-restore)
                   (progn (session-restore)
                          (if (daemonp) (org-mode-restart))) ; Restart org-mode to properly set faces for org files after loading with daemon
                   )))


    ;; Prevent desktop file from being locked on system and
    ;; Emacs crashes
    (defun emacs-process-p (pid)
      \"If pid is the process ID of an emacs process, return t, else nil.
              Also returns nil if pid is nil.\"
      (when pid
        (let* ((cmdline-file (concat \"/proc/\" (int-to-string pid) \"/cmdline\")))
          (when (file-exists-p cmdline-file)
            (with-temp-buffer
              (insert-file-contents-literally cmdline-file)
              (goto-char (point-min))
              (search-forward \"emacs\" nil t)
              pid)))))

    (defadvice desktop-owner (after pry-from-cold-dead-hands activate)
      \"Don't allow dead emacsen to own the desktop file.\"
      (when (not (emacs-process-p ad-return-value))
        (setq ad-return-value nil)))
    (defun kb/desktop-owner-advice (original &rest args)
      (let ((owner (apply original args)))
        (if (and owner (/= owner (emacs-pid)))
            (and (car (member owner (list-system-processes)))
                 (let (cmd (attrlist (process-attributes owner)))
                   (if (not attrlist) owner
                     (dolist (attr attrlist)
                       (and (string= \"comm\" (car attr))
                            (setq cmd (car attr))))
                     (and cmd (string-match-p \"[Ee]macs\" cmd) owner))))
          owner)))

    ;; Ensure that dead system processes don't own it.
    (advice-add #'desktop-owner :around #'kb/desktop-owner-advice)
    )
" . 43775) ((marker* . 52886) . 4520) ((marker . 52886) . -325) ((marker . 52720) . -325) ((marker* . 52959) . 4237) ((marker . 52720) . -353) ((marker . 52720) . -508) ((marker . 52720) . -247) ((marker . 52720) . -324) ((marker . 89622) . -431) ((marker . 43775) . -431) ((marker) . -508) ((marker) . -331) ((marker) . -353) ((marker) . -508) 44333 nil (44049 . 44050) ("12" . 44049) nil (44022 . 44101) 44049 (t 24470 47331 730493 695000) nil (114134 . 114136) ("t" . -114134) ((marker) . -1) ("h" . -114135) ((marker) . -1) ("e" . -114136) ((marker) . -1) ("m" . -114137) ((marker) . -1) 114138 (114127 . 114138) (" " . -114127) ((marker) . -1) ("w" . -114128) ((marker) . -1) ("r" . -114129) ((marker) . -1) ("i" . -114130) ((marker) . -1) ("t" . -114131) ((marker) . -1) ("e" . -114132) ((marker) . -1) (" " . -114133) ((marker) . -1) 114134 (114129 . 114134) ("i" . -114129) ((marker) . -1) 114130 (114128 . 114130) ("w" . -114128) ((marker) . -1) 114129 (114112 . 114129) (114092 . 114112) ("s" . -114092) ((marker) . -1) 114093 (114083 . 114093) nil (114138 . 114146) ("-" . -114138) ((marker) . -1) ((marker) . -1) 114139 (114138 . 114139) (t 24470 47154 779145 962000) nil (51746 . 51750) ("'" . 51746) (t 24470 47129 536087 126000) nil (51651 . 51655) nil ("g" . -51367) ((marker) . -1) ("a" . -51368) ((marker) . -1) 51369 (51367 . 51369) (t 24470 46907 645249 953000) nil ("(" . -51743) ((marker) . -1) ((marker) . -1) ("v" . -51744) ((marker) . -1) ((marker) . -1) ("i" . -51745) ((marker) . -1) ((marker) . -1) 51746 ("s" . -51746) ((marker) . -1) ((marker) . -1) ("u" . -51747) ((marker) . -1) ((marker) . -1) ("a" . -51748) ((marker) . -1) ((marker) . -1) ("l" . -51749) ((marker) . -1) ((marker) . -1) (" " . -51750) ((marker) . -1) ((marker) . -1) ("n" . -51751) ((marker) . -1) ((marker) . -1) ("o" . -51752) ((marker) . -1) ((marker) . -1) ("r" . -51753) ((marker) . -1) ((marker) . -1) ("m" . -51754) ((marker) . -1) ((marker) . -1) ("a" . -51755) ((marker) . -1) ((marker) . -1) ("l" . -51756) ((marker) . -1) ((marker) . -1) (" " . -51757) ((marker) . -1) ((marker) . -1) ("m" . -51758) ((marker) . -1) ((marker) . -1) ("o" . -51759) ((marker) . -1) ((marker) . -1) ("t" . -51760) ((marker) . -1) ((marker) . -1) ("i" . -51761) ((marker) . -1) ((marker) . -1) ("o" . -51762) ((marker) . -1) ("n" . -51763) ((marker) . -1) 51764 (51761 . 51764) ("o" . -51761) ((marker) . -1) ("n" . -51762) ((marker) . -1) 51763 (51750 . 51763) ("-" . -51750) ((marker) . -1) 51751 (51743 . 51751) (51742 . 51743) nil (51726 . 51731) nil (51635 . 51640) (t 24470 46759 330539 288000) nil (51665 . 51682) ("e" . 51665) ((marker) . -1) ("beye" . 51666) ((marker) . -4) (51665 . 51670) ("eyebrowse-" . 51665) ((marker) . -10) nil (51665 . 51675) ("e" . -51665) ((marker) . -1) ("b" . -51666) ((marker) . -1) ("e" . -51667) ((marker) . -1) ("y" . -51668) ((marker) . -1) ("e" . -51669) ((marker) . -1) 51670 (51666 . 51670) (51665 . 51666) ("(kbd \"C-c C-w r\")" . 51665) ((marker*) . 17) ((marker) . -1) ((marker*) . 1) ((marker) . -17) (t 24470 46759 330539 288000) nil (51004 . 51006) ("es" . 51004) nil (51081 . 51082) nil (51126 . 51127) nil (51079 . 51080) nil (51126 . 51127) nil (50867 . 52503) ("      (use-package eyebrowse
        :after (evil evil-collection)
        :custom
        (eyebrowse-default-workspace-slot 0) ; Start at 0
        (eyebrowes-keymap-prefix (kbd \"C-c C-w\"))
      (eyebrowse-mode-line-left-delimiter \"|\")
      (eyebrowse-mode-line-right-delimiter \"|\")
    (eyebrowse-mode-line-separator \" \")
  (eyebrowse-tagged-slot-format \"%t\") ; Only show workspace name (tag) if avail
(eyebrowse-wrap-around t) ; Not sure waht this does
        :config
        (eyebrowse-mode)

        (evil-define-key '(visual normal motion) 'global (kbd \"gt\") 'eyebrowse-next-window-config)
        (evil-define-key '(visual normal motion) 'global (kbd \"ga\") 'eyebrowse-prev-window-config)
        (evil-define-key '(visual normal motion) 'global (kbd \"gz\") 'eyebrowse-last-window-config)
        (define-key eyebrowse-mode-map (kbd \"C-c C-w r\") 'eyebrowse-rename-window-config)
        (define-key eyebrowse-mode-map (kbd \"C-c C-w c\") 'eyebrowse-close-window-config)
        (global-set-key (kbd \"M-1\") 'eyebrowse-switch-to-window-config-1)
        (global-set-key (kbd \"M-2\") 'eyebrowse-switch-to-window-config-2)
        (global-set-key (kbd \"M-3\") 'eyebrowse-switch-to-window-config-3)
        (global-set-key (kbd \"M-4\") 'eyebrowse-switch-to-window-config-4)
        (global-set-key (kbd \"M-5\") 'eyebrowse-switch-to-window-config-5)
        (global-set-key (kbd \"M-6\") 'eyebrowse-switch-to-window-config-6)
        (global-set-key (kbd \"M-7\") 'eyebrowse-switch-to-window-config-7)
        (global-set-key (kbd \"M-8\") 'eyebrowse-switch-to-window-config-8)
        (global-set-key (kbd \"M-9\") 'eyebrowse-switch-to-window-config-9)
        (global-set-key (kbd \"M-0\") 'eyebrowse-switch-to-window-config-0)
        )
" . 50867) ((marker* . 52886) . 1269) ((marker . 52886) . -457) ((marker . 52720) . -326) ((marker* . 52959) . 1268) ((marker . 52720) . -457) ((marker . 52720) . -377) ((marker) . -457) ((marker) . -377) 51193 (t 24470 46663 918464 5000)) (emacs-undo-equiv-table (-1 . -3) (-3 . -5) (-5 . -7) (-7 . -9) (-9 . -11) (-55 . -57) (-37 . -39) (-11 . -13) (-26 . -28) (-28 . -30)))